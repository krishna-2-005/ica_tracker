<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: login.php');
    exit;
}

$teacher_id = $_SESSION['user_id'];

$progress_query = "SELECT subject, topic, completion_percentage FROM syllabus_progress WHERE teacher_id='$teacher_id'";
$progress_result = mysqli_query($conn, $progress_query);

// Generate PDF
if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="progress_report.pdf"');

    $output = "%PDF-1.4\n";
    $output .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    $output .= "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
    $output .= "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R >>\nendobj\n";
    $output .= "4 0 obj\n<< /Length 5 0 R >>\nstream\n";
    $output .= "BT /F1 12 Tf 50 800 Td (Syllabus Progress Report) Tj ET\n";
    $output .= "BT /F1 12 Tf 50 780 Td (Subject) Tj 150 780 Td (Topic) Tj 300 780 Td (Completion %) Tj ET\n";

    $y = 760;
    mysqli_data_seek($progress_result, 0);
    while ($row = mysqli_fetch_assoc($progress_result)) {
        $output .= "BT /F1 12 Tf 50 $y Td ({$row['subject']}) Tj 150 $y Td ({$row['topic']}) Tj 300 $y Td ({$row['completion_percentage']}%) Tj ET\n";
        $y -= 20;
    }
    $output .= "endstream\nendobj\n";
    $output .= "5 0 obj\n" . strlen($output) . "\nendobj\n";
    $output .= "6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
    $output .= "xref\n0 7\n0000000000 65535 f \n0000000010 00000 n \n0000000075 00000 n \n0000000120 00000 n \n0000000175 00000 n \n0000000290 00000 n \n0000000350 00000 n \ntrailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n400\n%%EOF";

    echo $output;
    exit;
}

// Generate CSV
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="progress_report.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Subject', 'Topic', 'Completion %']);
    mysqli_data_seek($progress_result, 0);
    while ($row = mysqli_fetch_assoc($progress_result)) {
        fputcsv($output, [$row['subject'], $row['topic'], $row['completion_percentage']]);
    }
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reports</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Reports</h2>
        <table>
            <tr><th>Subject</th><th>Topic</th><th>Completion (%)</th></tr>
            <?php while ($row = mysqli_fetch_assoc($progress_result)) { ?>
                <tr>
                    <td><?php echo $row['subject']; ?></td>
                    <td><?php echo $row['topic']; ?></td>
                    <td><?php echo $row['completion_percentage']; ?>%</td>
                </tr>
            <?php } ?>
        </table>
        <p>
            <a href="?export=pdf">Download PDF</a> |
            <a href="?export=csv">Download CSV</a>
        </p>
        <p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>