<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: login.php');
    exit;
}

$teacher_id = $_SESSION['user_id'];

// Fetch assigned subjects
$subjects_query = "SELECT subject_name, total_planned_hours FROM teacher_subjects WHERE teacher_id='$teacher_id'";
$subjects_result = mysqli_query($conn, $subjects_query);

// Determine current week and default timeline
$semester_start = new DateTime('2025-04-01'); // Adjust this date as needed
$today = new DateTime();
$interval = $semester_start->diff($today);
$days_passed = $interval->days;
$current_week = min(ceil($days_passed / 7), 14); // Cap at 14 weeks

$default_timeline = '';
if ($current_week <= 5) {
    $default_timeline = 'mid1';
} elseif ($current_week <= 10) {
    $default_timeline = 'mid2';
} else {
    $default_timeline = 'final';
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $timeline = $_POST['timeline'];
    $modules_completed = (int)$_POST['modules_completed'];
    $actual_hours = (int)$_POST['actual_hours'];

    // Fetch total planned hours
    $planned_query = "SELECT total_planned_hours FROM teacher_subjects WHERE teacher_id='$teacher_id' AND subject_name='$subject'";
    $planned_result = mysqli_fetch_assoc(mysqli_query($conn, $planned_query));
    $total_planned_hours = $planned_result['total_planned_hours'];

    // Calculate cumulative planned hours
    $cumulative_planned_hours = 0;
    if ($timeline == 'mid1') {
        $cumulative_planned_hours = $total_planned_hours / 3;
    } elseif ($timeline == 'mid2') {
        $cumulative_planned_hours = ($total_planned_hours / 3) * 2;
    } elseif ($timeline == 'final') {
        $cumulative_planned_hours = $total_planned_hours;
    }

    // Calculate completion percentage
    $completion_percentage = ($actual_hours / $cumulative_planned_hours) * 100;

    // Insert or update progress
    $query = "INSERT INTO syllabus_progress (teacher_id, subject, timeline, modules_completed, planned_hours, actual_hours, completion_percentage, updated_at)
              VALUES ('$teacher_id', '$subject', '$timeline', '$modules_completed', '$cumulative_planned_hours', '$actual_hours', '$completion_percentage', NOW())
              ON DUPLICATE KEY UPDATE 
              modules_completed='$modules_completed', planned_hours='$cumulative_planned_hours', actual_hours='$actual_hours', completion_percentage='$completion_percentage', updated_at=NOW()";
    mysqli_query($conn, $query);

    // Trigger alert if progress is low
    if ($completion_percentage < 50) {
        $alert_message = "Syllabus progress for $subject ($timeline) is behind schedule.";
        $alert_query = "INSERT INTO alerts (teacher_id, message, status) VALUES ('$teacher_id', '$alert_message', 'pending')";
        mysqli_query($conn, $alert_query);
    }

    header('Location: update_progress.php');
    exit;
}

// Fetch recent progress
$recent_query = "SELECT subject, timeline, modules_completed, planned_hours, actual_hours, completion_percentage, updated_at 
                 FROM syllabus_progress WHERE teacher_id='$teacher_id' ORDER BY updated_at DESC LIMIT 5";
$recent_result = mysqli_query($conn, $recent_query);

// Check timeline completion status
$mid1_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM syllabus_progress WHERE teacher_id='$teacher_id' AND timeline='mid1'"))['count'] > 0;
$mid2_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM syllabus_progress WHERE teacher_id='$teacher_id' AND timeline='mid2'"))['count'] > 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Progress - ICA Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            line-height: 1.6;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #2c3e50 0%, #4a4a4a 100%);
            color: #e0e0e0;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #333333;
            color: #fff;
            padding: 20px;
            position: fixed;
            height: 100%;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: width 0.3s;
        }

        .sidebar h2 {
            font-size: 1.8rem;
            margin-bottom: 30px;
            text-align: center;
            color: #ecf0f1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #ecf0f1;
            text-decoration: none;
            padding: 12px 15px;
            margin: 10px 0;
            border-radius: 8px;
            transition: background 0.3s, transform 0.2s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #A6192E;
            transform: translateX(5px);
        }

        .sidebar a i {
            margin-right: 12px;
            font-size: 1.2rem;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s, width 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .header h2 {
            font-size: 2rem;
            color: #A6192E;
            font-weight: 600;
        }

        .theme-toggle {
            background: #A6192E;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s, transform 0.2s;
        }

        .theme-toggle:hover {
            background: #7f1422;
            transform: scale(1.05);
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
        }

        form {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        select, input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            background: #f9f9f9;
            transition: border-color 0.3s;
        }

        select:focus, input:focus {
            border-color: #A6192E;
            outline: none;
        }

        input[disabled] {
            background: #e9ecef;
            color: #666;
        }

        button {
            padding: 12px 25px;
            background: #A6192E;
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s, transform 0.2s;
        }

        button:hover {
            background: #7f1422;
            transform: scale(1.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        th {
            background: #A6192E;
            color: #fff;
            font-weight: 600;
        }

        body.dark-mode th {
            background: #4a4a4a;
        }

        tr:hover {
            background: #f9f9f9;
        }

        body.dark-mode tr:hover {
            background: #5a5a5a;
        }

        a {
            color: #A6192E;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        a:hover {
            color: #7f1422;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .sidebar h2, .sidebar a span {
                display: none;
            }

            .sidebar a i {
                margin-right: 0;
            }

            .main-content {
                margin-left: 70px;
                width: calc(100% - 70px);
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>ICA Tracker</h2>
            <a href="teacher_dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
            <a href="update_progress.php" class="active"><i class="fas fa-chart-line"></i> <span>Update Progress</span></a>
            <a href="manage_ica_marks.php"><i class="fas fa-book"></i> <span>Manage ICA Marks</span></a>
            <a href="view_alerts.php"><i class="fas fa-bell"></i> <span>View Alerts</span></a>
            <a href="view_reports.php"><i class="fas fa-file-alt"></i> <span>View Reports</span></a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
                <button class="theme-toggle" onclick="toggleTheme()">Toggle Theme</button>
            </div>
            <div class="container">
                <h2>Update Syllabus Progress</h2>
                <form method="POST" id="progressForm">
                    <label>Subject</label>
                    <select name="subject" id="subject" required onchange="updatePlannedHours()">
                        <option value="">Select a Subject</option>
                        <?php 
                        mysqli_data_seek($subjects_result, 0);
                        while ($subject = mysqli_fetch_assoc($subjects_result)) { ?>
                            <option value="<?php echo htmlspecialchars($subject['subject_name']); ?>" data-hours="<?php echo $subject['total_planned_hours']; ?>">
                                <?php echo htmlspecialchars($subject['subject_name']); ?>
                            </option>
                        <?php } ?>
                    </select>

                    <label>Timeline (Current Week: <?php echo $current_week; ?>)</label>
                    <select name="timeline" id="timeline" required onchange="updatePlannedHours()">
                        <option value="">Select Timeline</option>
                        <option value="mid1" <?php echo $default_timeline == 'mid1' ? 'selected' : ''; ?>>Mid1 (Up to Week 5)</option>
                        <option value="mid2" <?php echo !$mid1_completed ? 'disabled' : ($default_timeline == 'mid2' ? 'selected' : ''); ?>>Mid2 (Up to Week 10)</option>
                        <option value="final" <?php echo !$mid1_completed || !$mid2_completed ? 'disabled' : ($default_timeline == 'final' ? 'selected' : ''); ?>>Final (Up to Week 14)</option>
                    </select>

                    <label>No. of Modules Completed</label>
                    <input type="number" name="modules_completed" id="modules_completed" min="0" required>

                    <label>Planned Hours</label>
                    <input type="number" name="planned_hours" id="planned_hours" readonly>

                    <label>Actual Hours</label>
                    <input type="number" name="actual_hours" id="actual_hours" min="0" required oninput="calculatePercentage()">

                    <label>Percentage Completion</label>
                    <input type="text" name="completion_percentage" id="completion_percentage" readonly>

                    <button type="submit">Update Progress</button>
                </form>

                <h3>Recent Updates</h3>
                <table>
                    <tr>
                        <th>Subject</th>
                        <th>Timeline</th>
                        <th>Modules</th>
                        <th>Planned Hours</th>
                        <th>Actual Hours</th>
                        <th>Completion (%)</th>
                        <th>Updated</th>
                    </tr>
                    <?php while ($row = mysqli_fetch_assoc($recent_result)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['subject']); ?></td>
                            <td><?php echo ucfirst($row['timeline']); ?></td>
                            <td><?php echo htmlspecialchars($row['modules_completed']); ?></td>
                            <td><?php echo htmlspecialchars($row['planned_hours']); ?></td>
                            <td><?php echo htmlspecialchars($row['actual_hours']); ?></td>
                            <td><?php echo round($row['completion_percentage'], 2); ?>%</td>
                            <td><?php echo htmlspecialchars($row['updated_at']); ?></td>
                        </tr>
                    <?php } ?>
                </table>
                <p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
            </div>
        </div>
    </div>

    <script>
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }

        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
        }

        function updatePlannedHours() {
            const subjectSelect = document.getElementById('subject');
            const timelineSelect = document.getElementById('timeline');
            const plannedHoursInput = document.getElementById('planned_hours');

            const selectedSubject = subjectSelect.options[subjectSelect.selectedIndex];
            const totalHours = selectedSubject ? parseInt(selectedSubject.getAttribute('data-hours')) : 0;
            const timeline = timelineSelect.value;

            let plannedHours = 0;
            if (timeline === 'mid1') {
                plannedHours = totalHours / 3;
            } else if (timeline === 'mid2') {
                plannedHours = (totalHours / 3) * 2;
            } else if (timeline === 'final') {
                plannedHours = totalHours;
            }

            plannedHoursInput.value = plannedHours.toFixed(0);
            calculatePercentage();
        }

        function calculatePercentage() {
            const plannedHours = parseInt(document.getElementById('planned_hours').value) || 0;
            const actualHours = parseInt(document.getElementById('actual_hours').value) || 0;
            const percentage = plannedHours > 0 ? (actualHours / plannedHours) * 100 : 0;
            document.getElementById('completion_percentage').value = percentage.toFixed(2) + '%';
        }

        // Set default planned hours on page load
        window.onload = function() {
            updatePlannedHours();
        };
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</body>
</html>