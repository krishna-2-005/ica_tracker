<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: login.php');
    exit;
}

$teacher_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = $_POST['subject'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $deadline = $_POST['deadline'];

    $query = "INSERT INTO assignments (teacher_id, subject, title, description, deadline)
              VALUES ('$teacher_id', '$subject', '$title', '$description', '$deadline')";
    mysqli_query($conn, $query);
}

if (isset($_GET['complete_id'])) {
    $assignment_id = $_GET['complete_id'];
    $query = "UPDATE assignments SET status='completed' WHERE id='$assignment_id'";
    mysqli_query($conn, $query);
}

$assignments_query = "SELECT * FROM assignments WHERE teacher_id='$teacher_id'";
$assignments_result = mysqli_query($conn, $assignments_query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Assignments</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Manage Assignments</h2>
        <form method="POST">
            <label>Subject</label>
            <input type="text" name="subject" required>
            <label>Title</label>
            <input type="text" name="title" required>
            <label>Description</label>
            <textarea name="description"></textarea>
            <label>Deadline</label>
            <input type="date" name="deadline" required>
            <button type="submit">Add Assignment</button>
        </form>
        <h3>Assignments</h3>
        <table>
            <tr><th>Title</th><th>Deadline</th><th>Status</th><th>Action</th></tr>
            <?php while ($assignment = mysqli_fetch_assoc($assignments_result)) { ?>
                <tr>
                    <td><?php echo $assignment['title']; ?></td>
                    <td><?php echo $assignment['deadline']; ?></td>
                    <td><?php echo $assignment['status']; ?></td>
                    <td>
                        <?php if ($assignment['status'] == 'pending') { ?>
                            <a href="?complete_id=<?php echo $assignment['id']; ?>">Mark Complete</a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>