-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2025 at 07:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ica_tracker`
--

-- --------------------------------------------------------

--
-- Table structure for table `alerts`
--

CREATE TABLE `alerts` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `status` enum('pending','responded','resolved') DEFAULT 'pending',
  `response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `responded_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alerts`
--

INSERT INTO `alerts` (`id`, `teacher_id`, `message`, `status`, `response`, `created_at`, `responded_at`) VALUES
(1, 1, 'Syllabus progress for Mathematics is behind schedule.', 'responded', 'Yes sir it is completed', '2025-04-01 07:54:09', NULL),
(2, 1, 'Your syllabus is behind the timeline', 'responded', 'i will complete sir', '2025-04-01 08:23:00', NULL),
(3, 40002872, 'Complete the syllabus according to the date', 'responded', 'Okay sir i will', '2025-04-07 09:24:57', NULL),
(4, 40002872, 'Your Syllabus is lagging behind', 'responded', 'Yes sir i will complete this week\r\n', '2025-04-08 04:24:04', NULL),
(9, 40002872, 'HEllo', 'responded', 'hello ', '2025-04-08 07:01:47', '2025-04-08 07:18:11'),
(10, 40002872, 'mtt 1 marks are not submitted ', 'responded', 'i will do that by eod', '2025-04-08 07:20:08', '2025-04-08 07:21:15'),
(11, 40002872, 'mtt 2 marks are not updated ', 'responded', 'okay sir i will update by tomorrow', '2025-04-08 07:27:06', '2025-04-08 07:28:22'),
(12, 40002872, 'Syllabus progress for DAA (mid2) is behind schedule.', 'responded', 'I will cover the syllabus by 1 week sir ', '2025-04-09 19:01:07', '2025-04-09 19:02:26'),
(14, 40002872, 'Syllabus progress for DBMS (mid2) is behind schedule.', 'pending', NULL, '2025-04-11 05:38:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `deadline` date NOT NULL,
  `status` enum('pending','completed') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`id`, `teacher_id`, `subject`, `title`, `description`, `deadline`, `status`, `created_at`) VALUES
(1, 1, 'Mathematics', 'Algebra Assignment', 'Solve 10 problems', '2025-04-15', 'pending', '2025-04-01 07:54:09'),
(2, 40002872, 'DBMS', 'Normal ', 'Do the questions which we did in the class', '2025-04-04', 'completed', '2025-04-02 12:17:38');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `class_name` varchar(50) NOT NULL,
  `teacher_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `class_name`, `teacher_id`) VALUES
(1, 'CSEDS 3rd Year', 40002872),
(2, 'CSEDS 2nd Year', 40002872),
(3, 'CE 2nd Year', 40002872);

-- --------------------------------------------------------

--
-- Table structure for table `ica_marks`
--

CREATE TABLE `ica_marks` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `timeline` varchar(20) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `component_type` varchar(50) NOT NULL,
  `marks` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ica_marks`
--

INSERT INTO `ica_marks` (`id`, `teacher_id`, `subject`, `timeline`, `student_name`, `component_type`, `marks`) VALUES
(535, 40002872, 'DBMS', 'mid1', 'Sunny', 'mid1', 5),
(536, 40002872, 'DBMS', 'mid1', 'Alex', 'mid1', 4),
(537, 40002872, 'DBMS', 'mid1', 'Rayyan', 'mid1', 9),
(538, 40002872, 'DBMS', 'mid1', 'Sunny', 'experiment_1', 5),
(539, 40002872, 'DBMS', 'mid1', 'Alex', 'experiment_1', 4),
(540, 40002872, 'DBMS', 'mid1', 'Rayyan', 'experiment_1', 9),
(541, 40002872, 'DBMS', 'mid1', 'Sunny', 'experiment_2', 5),
(542, 40002872, 'DBMS', 'mid1', 'Alex', 'experiment_2', 4),
(543, 40002872, 'DBMS', 'mid1', 'Rayyan', 'experiment_2', 9),
(544, 40002872, 'DBMS', 'mid1', 'Sunny', 'experiment_3', 5),
(545, 40002872, 'DBMS', 'mid1', 'Alex', 'experiment_3', 4),
(546, 40002872, 'DBMS', 'mid1', 'Rayyan', 'experiment_3', 9),
(547, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_1', 5),
(548, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_1', 4),
(549, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_1', 9),
(550, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_2', 5),
(551, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_2', 4),
(552, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_2', 9),
(553, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_3', 5),
(554, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_3', 4),
(555, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_3', 9),
(556, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_4', 5),
(557, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_4', 4),
(558, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_4', 9),
(559, 40002872, 'DBMS', 'mid1', 'Sunny', 'mid1', 5),
(560, 40002872, 'DBMS', 'mid1', 'Alex', 'mid1', 5),
(561, 40002872, 'DBMS', 'mid1', 'Rayyan', 'mid1', 5),
(562, 40002872, 'DBMS', 'mid1', 'Sunny', 'experiment_1', 5),
(563, 40002872, 'DBMS', 'mid1', 'Alex', 'experiment_1', 5),
(564, 40002872, 'DBMS', 'mid1', 'Rayyan', 'experiment_1', 5),
(565, 40002872, 'DBMS', 'mid1', 'Sunny', 'experiment_2', 5),
(566, 40002872, 'DBMS', 'mid1', 'Alex', 'experiment_2', 5),
(567, 40002872, 'DBMS', 'mid1', 'Rayyan', 'experiment_2', 5),
(568, 40002872, 'DBMS', 'mid1', 'Sunny', 'experiment_3', 5),
(569, 40002872, 'DBMS', 'mid1', 'Alex', 'experiment_3', 5),
(570, 40002872, 'DBMS', 'mid1', 'Rayyan', 'experiment_3', 5),
(571, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_1', 5),
(572, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_1', 5),
(573, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_1', 5),
(574, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_2', 5),
(575, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_2', 5),
(576, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_2', 5),
(577, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_3', 5),
(578, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_3', 5),
(579, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_3', 5),
(580, 40002872, 'DBMS', 'mid1', 'Sunny', 'assignment_4', 5),
(581, 40002872, 'DBMS', 'mid1', 'Alex', 'assignment_4', 5),
(582, 40002872, 'DBMS', 'mid1', 'Rayyan', 'assignment_4', 5),
(583, 40002872, 'DBMS', 'mid2', 'Sunny', 'mid2', 8),
(584, 40002872, 'DBMS', 'mid2', 'Alex', 'mid2', 8),
(585, 40002872, 'DBMS', 'mid2', 'Rayyan', 'mid2', 8),
(586, 40002872, 'DBMS', 'mid2', 'Sunny', 'experiment_7', 8),
(587, 40002872, 'DBMS', 'mid2', 'Alex', 'experiment_7', 8),
(588, 40002872, 'DBMS', 'mid2', 'Rayyan', 'experiment_7', 8),
(589, 40002872, 'DBMS', 'mid2', 'Sunny', 'experiment_8', 8),
(590, 40002872, 'DBMS', 'mid2', 'Alex', 'experiment_8', 8),
(591, 40002872, 'DBMS', 'mid2', 'Rayyan', 'experiment_8', 8),
(592, 40002872, 'DBMS', 'mid2', 'Sunny', 'experiment_9', 8),
(593, 40002872, 'DBMS', 'mid2', 'Alex', 'experiment_9', 8),
(594, 40002872, 'DBMS', 'mid2', 'Rayyan', 'experiment_9', 8),
(595, 40002872, 'DBMS', 'mid2', 'Sunny', 'assignment_1', 8),
(596, 40002872, 'DBMS', 'mid2', 'Alex', 'assignment_1', 8),
(597, 40002872, 'DBMS', 'mid2', 'Rayyan', 'assignment_1', 8),
(598, 40002872, 'DBMS', 'mid2', 'Sunny', 'mid2', 8),
(599, 40002872, 'DBMS', 'mid2', 'Alex', 'mid2', 8),
(600, 40002872, 'DBMS', 'mid2', 'Rayyan', 'mid2', 8),
(601, 40002872, 'DBMS', 'mid2', 'Sunny', 'experiment_7', 8),
(602, 40002872, 'DBMS', 'mid2', 'Alex', 'experiment_7', 8),
(603, 40002872, 'DBMS', 'mid2', 'Rayyan', 'experiment_7', 8),
(604, 40002872, 'DBMS', 'mid2', 'Sunny', 'experiment_8', 8),
(605, 40002872, 'DBMS', 'mid2', 'Alex', 'experiment_8', 8),
(606, 40002872, 'DBMS', 'mid2', 'Rayyan', 'experiment_8', 8),
(607, 40002872, 'DBMS', 'mid2', 'Sunny', 'experiment_9', 8),
(608, 40002872, 'DBMS', 'mid2', 'Alex', 'experiment_9', 8),
(609, 40002872, 'DBMS', 'mid2', 'Rayyan', 'experiment_9', 8),
(610, 40002872, 'DBMS', 'mid2', 'Sunny', 'assignment_1', 8),
(611, 40002872, 'DBMS', 'mid2', 'Alex', 'assignment_1', 8),
(612, 40002872, 'DBMS', 'mid2', 'Rayyan', 'assignment_1', 8),
(613, 40002872, 'DBMS', 'final_ica', 'Sunny', 'final_ica', 0),
(614, 40002872, 'DBMS', 'final_ica', 'Alex', 'final_ica', 0),
(615, 40002872, 'DBMS', 'final_ica', 'Rayyan', 'final_ica', 0),
(616, 40002872, 'DBMS', 'final_ica', 'Sunny', 'project_presentation', 7),
(617, 40002872, 'DBMS', 'final_ica', 'Alex', 'project_presentation', 7),
(618, 40002872, 'DBMS', 'final_ica', 'Rayyan', 'project_presentation', 7),
(619, 40002872, 'DBMS', 'final_ica', 'Sunny', 'lab_exam', 5),
(620, 40002872, 'DBMS', 'final_ica', 'Alex', 'lab_exam', 5),
(621, 40002872, 'DBMS', 'final_ica', 'Rayyan', 'lab_exam', 5),
(622, 40002872, 'DBMS', 'final_ica', 'Sunny', 'class_participation', 5),
(623, 40002872, 'DBMS', 'final_ica', 'Alex', 'class_participation', 5),
(624, 40002872, 'DBMS', 'final_ica', 'Rayyan', 'class_participation', 5),
(625, 40002872, 'DAA', 'mid1', 'Karthik', 'mid1', 5),
(626, 40002872, 'DAA', 'mid1', 'Sahil', 'mid1', 5),
(627, 40002872, 'DAA', 'mid1', 'Ratna Chand', 'mid1', 5),
(628, 40002872, 'DAA', 'mid1', 'Karthik', 'experiment_1', 5),
(629, 40002872, 'DAA', 'mid1', 'Sahil', 'experiment_1', 5),
(630, 40002872, 'DAA', 'mid1', 'Ratna Chand', 'experiment_1', 5),
(631, 40002872, 'DAA', 'mid1', 'Karthik', 'experiment_2', 5),
(632, 40002872, 'DAA', 'mid1', 'Sahil', 'experiment_2', 5),
(633, 40002872, 'DAA', 'mid1', 'Ratna Chand', 'experiment_2', 5),
(634, 40002872, 'DAA', 'mid1', 'Karthik', 'experiment_3', 5),
(635, 40002872, 'DAA', 'mid1', 'Sahil', 'experiment_3', 5),
(636, 40002872, 'DAA', 'mid1', 'Ratna Chand', 'experiment_3', 5),
(637, 40002872, 'DAA', 'mid1', 'Karthik', 'assignment_1', 5),
(638, 40002872, 'DAA', 'mid1', 'Sahil', 'assignment_1', 5),
(639, 40002872, 'DAA', 'mid1', 'Ratna Chand', 'assignment_1', 5),
(640, 40002872, 'DAA', 'mid1', 'Karthik', 'assignment_2', 5),
(641, 40002872, 'DAA', 'mid1', 'Sahil', 'assignment_2', 5),
(642, 40002872, 'DAA', 'mid1', 'Ratna Chand', 'assignment_2', 5),
(643, 40002872, 'ADSA', 'mid1', 'Shiva', 'mid1', 4),
(644, 40002872, 'ADSA', 'mid1', 'Lahari', 'mid1', 4),
(645, 40002872, 'ADSA', 'mid1', 'Rishikesh', 'mid1', 4),
(646, 40002872, 'ADSA', 'mid1', 'Shiva', 'experiment_1', 4),
(647, 40002872, 'ADSA', 'mid1', 'Lahari', 'experiment_1', 4),
(648, 40002872, 'ADSA', 'mid1', 'Rishikesh', 'experiment_1', 4),
(649, 40002872, 'ADSA', 'mid1', 'Shiva', 'experiment_2', 4),
(650, 40002872, 'ADSA', 'mid1', 'Lahari', 'experiment_2', 4),
(651, 40002872, 'ADSA', 'mid1', 'Rishikesh', 'experiment_2', 4),
(652, 40002872, 'ADSA', 'mid1', 'Shiva', 'experiment_3', 4),
(653, 40002872, 'ADSA', 'mid1', 'Lahari', 'experiment_3', 4),
(654, 40002872, 'ADSA', 'mid1', 'Rishikesh', 'experiment_3', 4),
(655, 40002872, 'ADSA', 'mid1', 'Shiva', 'assignment_1', 4),
(656, 40002872, 'ADSA', 'mid1', 'Lahari', 'assignment_1', 4),
(657, 40002872, 'ADSA', 'mid1', 'Rishikesh', 'assignment_1', 4),
(658, 40002872, 'ADSA', 'mid1', 'Shiva', 'assignment_2', 4),
(659, 40002872, 'ADSA', 'mid1', 'Lahari', 'assignment_2', 4),
(660, 40002872, 'ADSA', 'mid1', 'Rishikesh', 'assignment_2', 4);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `roll_number` varchar(10) NOT NULL,
  `class_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `roll_number`, `class_id`, `teacher_id`) VALUES
(1, 'Shiva', 'D001', 1, 40002872),
(2, 'Lahari', 'D002', 1, 40002872),
(3, 'Rishikesh', 'D003', 1, 40002872),
(4, 'Sunny', 'D004', 2, 40002872),
(5, 'Alex', 'D005', 2, 40002872),
(6, 'Rayyan', 'D006', 2, 40002872),
(7, 'Karthik', 'D007', 3, 40002872),
(8, 'Sahil', 'D008', 3, 40002872),
(9, 'Ratna Chand', 'D009', 3, 40002872);

-- --------------------------------------------------------

--
-- Table structure for table `syllabus_progress`
--

CREATE TABLE `syllabus_progress` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `planned_hours` int(11) NOT NULL,
  `actual_hours` int(11) DEFAULT 0,
  `completion_percentage` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `timeline` enum('mid1','mid2','final') NOT NULL,
  `modules_completed` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `syllabus_progress`
--

INSERT INTO `syllabus_progress` (`id`, `teacher_id`, `subject`, `topic`, `planned_hours`, `actual_hours`, `completion_percentage`, `updated_at`, `timeline`, `modules_completed`) VALUES
(17, 40002872, 'DBMS', '', 20, 18, 90, '2025-04-09 18:45:50', 'mid1', 3),
(18, 40002872, 'ADSA', '', 20, 17, 85, '2025-04-09 18:46:04', 'mid1', 2),
(20, 40002872, 'DAA', '', 30, 15, 50, '2025-04-09 18:51:11', 'mid2', 6),
(21, 40002872, 'DAA', '', 30, 12, 40, '2025-04-09 19:01:07', 'mid2', 5),
(22, 40002872, 'DAA', '', 30, 9, 30, '2025-04-09 19:03:14', 'mid2', 3),
(25, 40002872, 'DBMS', '', 40, 15, 38, '2025-04-11 05:38:41', 'mid2', 4);

-- --------------------------------------------------------

--
-- Table structure for table `teacher_subjects`
--

CREATE TABLE `teacher_subjects` (
  `id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `total_planned_hours` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher_subjects`
--

INSERT INTO `teacher_subjects` (`id`, `teacher_id`, `subject_name`, `total_planned_hours`) VALUES
(1, 40002872, 'ADSA', 60),
(2, 40002872, 'DBMS', 60),
(3, 40002872, 'DAA', 45);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('teacher','program_chair') NOT NULL,
  `email` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `email`, `name`) VALUES
(1, 'teacher1', '482c811da5d5b4bc6d497ffa98491e38', 'teacher', 'teacher1@example.com', 'Teacher One'),
(2, 'chair1', '0192023a7bbd73250516f069df18b500', 'program_chair', 'chair1@example.com', 'Program Chair'),
(40002871, 'Lahari', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', '', 'Makkena Lahari'),
(40002872, 'Wasiha_Tasneem', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', '', 'Wasiha Tasneem '),
(40002873, 'Shiva_Ganesh', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', '', 'Shiva Ganesh'),
(40002874, 'Chandrakant_Wani', 'e10adc3949ba59abbe56e057f20f883e', 'program_chair', '', 'Chandrakant Wani'),
(40004479, 'Naresh_Vurukonda', 'e10adc3949ba59abbe56e057f20f883e', 'teacher', '', 'Dr Naresh Vurukonda');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alerts`
--
ALTER TABLE `alerts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `ica_marks`
--
ALTER TABLE `ica_marks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_teacher_timeline` (`teacher_id`,`timeline`,`student_name`,`component_type`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `syllabus_progress`
--
ALTER TABLE `syllabus_progress`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `teacher_id` (`teacher_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alerts`
--
ALTER TABLE `alerts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ica_marks`
--
ALTER TABLE `ica_marks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=661;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `syllabus_progress`
--
ALTER TABLE `syllabus_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40004481;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `alerts`
--
ALTER TABLE `alerts`
  ADD CONSTRAINT `alerts_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `classes`
--
ALTER TABLE `classes`
  ADD CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`);

--
-- Constraints for table `syllabus_progress`
--
ALTER TABLE `syllabus_progress`
  ADD CONSTRAINT `syllabus_progress_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `teacher_subjects`
--
ALTER TABLE `teacher_subjects`
  ADD CONSTRAINT `teacher_subjects_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
