<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: login.php');
    exit;
}

$teacher_id = $_SESSION['user_id'];

// Fetch syllabus progress
$progress_query = "SELECT subject, AVG(completion_percentage) as avg_completion FROM syllabus_progress WHERE teacher_id='$teacher_id' GROUP BY subject";
$progress_result = mysqli_query($conn, $progress_query);

// Fetch assignments
$assignments_query = "SELECT title, deadline, status FROM assignments WHERE teacher_id='$teacher_id'";
$assignments_result = mysqli_query($conn, $assignments_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Reports - ICA Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: #F5F5F5;
            color: #333333;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: #4A4A4A;
            color: #FFFFFF;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: #333333;
            color: #FFFFFF;
            padding: 20px;
            position: fixed;
            height: 100%;
            transition: width 0.3s;
        }

        .sidebar h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            text-align: center;
            color: #FFFFFF;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #FFFFFF;
            text-decoration: none;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #A6192E;
            color: #FFFFFF;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s, width 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #FFFFFF;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .header h2 {
            font-size: 1.8rem;
            color: #A6192E;
        }

        .theme-toggle {
            background: #A6192E;
            color: #FFFFFF;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .theme-toggle:hover {
            background: #666666;
        }

        .container {
            margin-left: 0;
            padding: 0;
        }

        .card {
            background: #FFFFFF;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #FFFFFF;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E0E0E0;
        }

        th {
            background: #A6192E;
            color: #FFFFFF;
        }

        body.dark-mode th {
            background: #4A4A4A;
        }

        tr:hover {
            background: #F9F9F9;
        }

        body.dark-mode tr:hover {
            background: #6A6A6A;
        }

        a {
            color: #A6192E;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
            }

            .sidebar h2, .sidebar a span {
                display: none;
            }

            .main-content {
                margin-left: 60px;
                width: calc(100% - 60px);
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>ICA Tracker</h2>
            <a href="teacher_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="update_progress.php"><i class="fas fa-chart-line"></i> Update Progress</a>
            <a href="manage_ica_marks.php"><i class="fas fa-book"></i> Manage ICA Marks</a>
            <a href="view_alerts.php"><i class="fas fa-bell"></i> View Alerts</a>
            <a href="view_reports.php" class="active"><i class="fas fa-file-alt"></i> View Reports</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
                <button class="theme-toggle" onclick="document.body.classList.toggle('dark-mode')">Toggle Theme</button>
            </div>
            <div class="container">
                <h2>View Reports</h2>
                <div class="card">
                    <h3>Syllabus Progress</h3>
                    <table>
                        <tr>
                            <th>Subject</th>
                            <th>Average Completion (%)</th>
                        </tr>
                        <?php while ($row = mysqli_fetch_assoc($progress_result)) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['subject']); ?></td>
                                <td><?php echo round($row['avg_completion'], 2); ?>%</td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
                <div class="card">
                    <h3>Assignments</h3>
                    <table>
                        <tr>
                            <th>Title</th>
                            <th>Deadline</th>
                            <th>Status</th>
                        </tr>
                        <?php while ($assignment = mysqli_fetch_assoc($assignments_result)) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($assignment['title']); ?></td>
                                <td><?php echo htmlspecialchars($assignment['deadline']); ?></td>
                                <td><?php echo htmlspecialchars($assignment['status']); ?></td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
                <p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
            </div>
        </div>
    </div>

    <script>
        // Theme toggle persistence
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
        }
        document.querySelector('.theme-toggle').addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</body>
</html>