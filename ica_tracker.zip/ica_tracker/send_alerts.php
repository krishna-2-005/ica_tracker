<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'program_chair') {
    header('Location: login.php');
    exit;
}

// Handle sending alert
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['send_alert'])) {
    $teacher_id = (int)$_POST['teacher_id'];
    $message = mysqli_real_escape_string($conn, $_POST['message']);
    $query = "INSERT INTO alerts (teacher_id, message, status, created_at) VALUES ('$teacher_id', '$message', 'pending', NOW())";
    if (mysqli_query($conn, $query)) {
        header('Location: send_alerts.php');
        exit;
    }
}

// Fetch teachers for the dropdown
$teachers_query = "SELECT id, name FROM users WHERE role='teacher'";
$teachers_result = mysqli_query($conn, $teachers_query);

// Fetch sent alerts and their responses (joining with users table to get teacher names)
$program_chair_id = $_SESSION['user_id'];
$alerts_query = "SELECT a.id, u.name AS teacher_name, a.message, a.response, a.status, a.created_at 
                 FROM alerts a 
                 JOIN users u ON a.teacher_id = u.id 
                 WHERE a.teacher_id IN (SELECT id FROM users WHERE role='teacher')";
$alerts_result = mysqli_query($conn, $alerts_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Alerts - ICA Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: #F5F5F5;
            color: #333333;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: #4A4A4A;
            color: #FFFFFF;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar */
        .sidebar {
            width: 250px;
            background: #333333;
            color: #FFFFFF;
            padding: 20px;
            position: fixed;
            height: 100%;
            transition: width 0.3s;
        }

        .sidebar h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            text-align: center;
            color: #FFFFFF;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #FFFFFF;
            text-decoration: none;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #A6192E;
            color: #FFFFFF;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s, width 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #FFFFFF;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .header h2 {
            font-size: 1.8rem;
            color: #A6192E;
        }

        .theme-toggle {
            background: #A6192E;
            color: #FFFFFF;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .theme-toggle:hover {
            background: #666666;
        }

        .container {
            margin-left: 0;
            padding: 0;
        }

        .card {
            background: #FFFFFF;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        select, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #666666;
            border-radius: 5px;
            font-size: 1rem;
        }

        button {
            padding: 8px 15px;
            background: #A6192E;
            color: #FFFFFF;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            transition: background 0.3s;
        }

        button:hover {
            background: #333333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #FFFFFF;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E0E0E0;
        }

        th {
            background: #A6192E;
            color: #FFFFFF;
        }

        body.dark-mode th {
            background: #4A4A4A;
        }

        tr:hover {
            background: #F9F9F9;
        }

        body.dark-mode tr:hover {
            background: #6A6A6A;
        }

        a {
            color: #A6192E;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
            }

            .sidebar h2, .sidebar a span {
                display: none;
            }

            .main-content {
                margin-left: 60px;
                width: calc(100% - 60px);
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>ICA Tracker</h2>
            <a href="program_dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="teacher_progress.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a>
            <a href="student_progress.php"><i class="fas fa-user-graduate"></i> Students</a>
            <a href="course_progress.php"><i class="fas fa-book"></i> Courses</a>
            <a href="view_reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="send_alerts.php" class="active"><i class="fas fa-bell"></i> Alerts</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
                <button class="theme-toggle" onclick="document.body.classList.toggle('dark-mode')">Toggle Theme</button>
            </div>
            <div class="container">
                <h2>Send Alerts</h2>
                <div class="card">
                    <form method="POST">
                        <label>Select Teacher</label>
                        <select name="teacher_id" required>
                            <option value="">Select a Teacher</option>
                            <?php while ($teacher = mysqli_fetch_assoc($teachers_result)) { ?>
                                <option value="<?php echo $teacher['id']; ?>"><?php echo htmlspecialchars($teacher['name']); ?></option>
                            <?php } ?>
                        </select>
                        <label>Message</label>
                        <textarea name="message" rows="4" required></textarea>
                        <button type="submit" name="send_alert">Send Alert</button>
                    </form>
                </div>

                <!-- Teacher Responses -->
                <div class="card">
                    <h3>Teacher Responses</h3>
                    <table>
                        <tr>
                            <th>Teacher</th>
                            <th>Message</th>
                            <th>Response</th>
                        </tr>
                        <?php while ($alert = mysqli_fetch_assoc($alerts_result)) { ?>
                            <tr>
                                <td><?php echo htmlspecialchars($alert['teacher_name']); ?></td>
                                <td><?php echo htmlspecialchars($alert['message']); ?></td>
                                <td><?php echo htmlspecialchars($alert['response'] ?? 'No response'); ?></td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>

                <p><a href="program_dashboard.php">Back to Dashboard</a></p>
            </div>
        </div>
    </div>

    <script>
        // Theme toggle persistence
        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
        }
        document.querySelector('.theme-toggle').addEventListener('click', () => {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        });
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</body>
</html>