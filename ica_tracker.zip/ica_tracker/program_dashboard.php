<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'program_chair') {
    header('Location: login.php');
    exit;
}

// Fetch total courses
$total_courses_query = "SELECT COUNT(DISTINCT subject_name) AS total_courses FROM teacher_subjects";
$total_courses_result = mysqli_query($conn, $total_courses_query);
$total_courses = mysqli_fetch_assoc($total_courses_result)['total_courses'] ?: 0;

// Fetch average syllabus covered
$syllabus_covered_query = "SELECT AVG(completion_percentage) AS avg_syllabus FROM syllabus_progress";
$syllabus_covered_result = mysqli_query($conn, $syllabus_covered_query);
$avg_syllabus = round(mysqli_fetch_assoc($syllabus_covered_result)['avg_syllabus'] ?: 0);

// Fetch low performing students (average ICA mark < 50%)
$low_performing_students_query = "
    SELECT COUNT(DISTINCT student_name) AS low_performing
    FROM ica_marks
    WHERE teacher_id IN (SELECT id FROM users WHERE role = 'teacher')
    GROUP BY teacher_id, student_name
    HAVING AVG(marks) < 50";
$low_performing_students_result = mysqli_query($conn, $low_performing_students_query);
$low_performing_students = 0;
while ($row = mysqli_fetch_assoc($low_performing_students_result)) {
    $low_performing_students += $row['low_performing'];
}

// Fetch classes
$classes_query = "SELECT id, class_name FROM classes";
$classes_result = mysqli_query($conn, $classes_query);
$classes = ['all' => 'All Classes'];
while ($row = mysqli_fetch_assoc($classes_result)) {
    $classes[$row['id']] = $row['class_name'];
}
$selected_class_id = isset($_GET['class']) && array_key_exists($_GET['class'], $classes) ? $_GET['class'] : 'all';

// Updated class-subject mapping based on year and stream
$class_subjects = [
    '1' => ['ADSA'],          // 3rd Year
    '2' => ['DBMS'],          // 2nd Year CSD
    '3' => ['DAA']            // 2nd Year CE
];

// Fetch MST data
$mst_query = "
    SELECT im.subject, im.component_type, AVG(im.marks) AS avg_marks
    FROM ica_marks im
    JOIN users u ON im.teacher_id = u.id
    WHERE im.component_type IN ('mid1', 'mid2')
    AND u.role = 'teacher'
    GROUP BY im.subject, im.component_type
    ORDER BY im.subject, im.component_type";
$mst_result = mysqli_query($conn, $mst_query);

$mst_data = [];
while ($row = mysqli_fetch_assoc($mst_result)) {
    $subject = $row['subject'];
    $component_type = $row['component_type'];
    $avg_marks = round($row['avg_marks'] * 10, 0); // Convert to percentage (assuming marks out of 10)
    if (!isset($mst_data[$subject])) {
        $mst_data[$subject] = ['MST1' => 0, 'MST2' => 0];
    }
    if ($component_type == 'mid1') $mst_data[$subject]['MST1'] = $avg_marks;
    elseif ($component_type == 'mid2') $mst_data[$subject]['MST2'] = $avg_marks;
}

// Ensure all subjects from teacher_subjects are included
$all_subjects_query = "SELECT DISTINCT subject_name FROM teacher_subjects";
$all_subjects_result = mysqli_query($conn, $all_subjects_query);
$all_subjects = [];
while ($row = mysqli_fetch_assoc($all_subjects_result)) {
    $all_subjects[] = $row['subject_name'];
    if (!isset($mst_data[$row['subject_name']])) {
        $mst_data[$row['subject_name']] = ['MST1' => 0, 'MST2' => 0];
    }
}

// Fetch ICA data
$ica_query = "
    SELECT im.subject, AVG(im.marks) AS ica_avg
    FROM ica_marks im
    JOIN users u ON im.teacher_id = u.id
    WHERE im.component_type = 'final_ica'
    AND u.role = 'teacher'
    GROUP BY im.subject";
$ica_result = mysqli_query($conn, $ica_query);
$ica_data = [];
while ($row = mysqli_fetch_assoc($ica_result)) {
    $ica_data[$row['subject']] = round($row['ica_avg'] * 10, 0); // Convert to percentage
}

// Fetch syllabus coverage data for each subject
$syllabus_data = [];
$subjects = ($selected_class_id === 'all') ? $all_subjects : $class_subjects[$selected_class_id] ?? [];
foreach ($subjects as $subject) {
    $syllabus_query = "
        SELECT timeline, MAX(completion_percentage) AS avg_completion
        FROM syllabus_progress
        WHERE subject = ?
        GROUP BY timeline
        ORDER BY timeline";
    $stmt = mysqli_prepare($conn, $syllabus_query);
    mysqli_stmt_bind_param($stmt, "s", $subject);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $data = ['Mid1' => 0, 'Mid2' => 0, 'Final' => 0];
    while ($row = mysqli_fetch_assoc($result)) {
        $timeline = ucfirst($row['timeline']);
        $data[$timeline] = $row['avg_completion'];
    }
    $syllabus_data[$subject] = $data;
    mysqli_stmt_close($stmt);
}

// Filter subjects based on selected class
$filtered_subjects = ($selected_class_id === 'all') ? $all_subjects : $class_subjects[$selected_class_id] ?? [];
$filtered_mst_data = array_intersect_key($mst_data, array_flip($filtered_subjects));

// Fetch teacher performance data with deduplication
$progress_query = "
    SELECT 
        u.name AS teacher_name,
        ts.subject_name AS course_name,
        sp.timeline,
        MAX(sp.completion_percentage) AS avg_completion,
        MAX(sp.updated_at) AS latest_update,
        u.id AS teacher_id
    FROM syllabus_progress sp
    JOIN users u ON sp.teacher_id = u.id
    JOIN teacher_subjects ts ON sp.teacher_id = ts.teacher_id AND sp.subject = ts.subject_name
    WHERE u.role = 'teacher'
    GROUP BY u.id, ts.subject_name, sp.timeline
    ORDER BY u.name, sp.timeline";
$progress_result = mysqli_query($conn, $progress_query);

// Fetch assignments
$teacher_assignments = [];
$assignments_query = "SELECT teacher_id, COUNT(*) AS total_assignments FROM assignments GROUP BY teacher_id";
$assignments_result = mysqli_query($conn, $assignments_query);
while ($assign = mysqli_fetch_assoc($assignments_result)) {
    $teacher_assignments[$assign['teacher_id']] = $assign['total_assignments'];
}

// Fetch alerts
$alerts_query = "SELECT a.*, u.name FROM alerts a JOIN users u ON a.teacher_id = u.id WHERE a.status='pending'";
$alerts_result = mysqli_query($conn, $alerts_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Program Chair Dashboard - ICA Tracker</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: #F5F5F5;
            color: #333333;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: #4A4A4A;
            color: #FFFFFF;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #333333;
            color: #FFFFFF;
            padding: 20px;
            position: fixed;
            height: 100%;
            transition: width 0.3s;
        }

        .sidebar h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            text-align: center;
            color: #FFFFFF;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #FFFFFF;
            text-decoration: none;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            transition: background 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #A6192E;
            color: #FFFFFF;
        }

        .sidebar a i {
            margin-right: 10px;
        }

        .main-content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s, width 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #FFFFFF;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .header h2 {
            font-size: 1.8rem;
            color: #A6192E;
        }

        .theme-toggle {
            background: #A6192E;
            color: #FFFFFF;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            cursor: pointer;
            transition: background 0.3s;
        }

        .theme-toggle:hover {
            background: #666666;
        }

        .container {
            margin-left: 0;
            padding: 0;
        }

        .card {
            background: #FFFFFF;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .progress {
            height: 10px;
            border-radius: 5px;
            background: #E0E0E0;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            text-align: right;
            padding-right: 5px;
            color: #333333;
            transition: width 0.3s;
        }

        .progress-bar.bg-warning {
            background-color: #FFFF33;
        }

        .progress-bar.bg-success {
            background-color: #33CC33;
        }

        .progress-bar.bg-danger {
            background-color: #FF3333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #FFFFFF;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E0E0E0;
        }

        th {
            background: #A6192E;
            color: #FFFFFF;
        }

        body.dark-mode th {
            background: #4A4A4A;
        }

        tr:hover {
            background: #F9F9F9;
        }

        body.dark-mode tr:hover {
            background: #6A6A6A;
        }

        a {
            color: #A6192E;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        .chart-container {
            position: relative;
            height: 400px;
            margin-top: 20px;
        }

        .card-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }

        .info-card {
            flex: 1;
            background: #fff;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
            cursor: pointer;
        }

        .info-card:hover {
            transform: translateY(-5px);
        }

        .info-card.blue {
            background: #4A90E2;
            color: #fff;
        }

        .info-card.yellow {
            background: #F5A623;
            color: #fff;
        }

        .info-card.red {
            background: #D0021B;
            color: #fff;
        }

        .info-card i {
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .info-card .value {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .info-card .label {
            font-size: 1rem;
        }

        .filter-container {
            text-align: right;
            margin-bottom: 20px;
        }

        .filter-container select {
            padding: 5px 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1rem;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 60px;
            }

            .sidebar h2, .sidebar a span {
                display: none;
            }

            .main-content {
                margin-left: 60px;
                width: calc(100% - 60px);
            }

            .card-row {
                flex-direction: column;
            }

            .info-card {
                width: 100%;
            }

            .filter-container {
                text-align: left;
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>ICA Tracker</h2>
            <a href="program_dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            <a href="teacher_progress.php"><i class="fas fa-chalkboard-teacher"></i> Teachers</a>
            <a href="student_progress.php"><i class="fas fa-user-graduate"></i> Students</a>
            <a href="course_progress.php"><i class="fas fa-book"></i> Courses</a>
            <a href="program_reports.php"><i class="fas fa-chart-bar"></i> Reports</a>
            <a href="send_alerts.php"><i class="fas fa-bell"></i> Alerts</a>
            <a href="settings.php"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
                <button class="theme-toggle" onclick="toggleTheme()">Toggle Theme</button>
            </div>
            <div class="container">
                <!-- Overview Cards -->
                <div class="card-row">
                    <div class="info-card blue" onclick="window.location.href='course_progress.php'">
                        <i class="fas fa-book"></i>
                        <div class="value"><?php echo $total_courses; ?></div>
                        <div class="label">Total Courses</div>
                    </div>
                    <div class="info-card yellow" onclick="window.location.href='program_reports.php'">
                        <i class="fas fa-check-double"></i>
                        <div class="value"><?php echo $avg_syllabus; ?>%</div>
                        <div class="label">Syllabus Covered</div>
                    </div>
                    <div class="info-card red" onclick="window.location.href='student_progress.php?filter=low'">
                        <i class="fas fa-exclamation-triangle"></i>
                        <div class="value"><?php echo $low_performing_students; ?></div>
                        <div class="label">Low Performing Students</div>
                    </div>
                </div>

                <!-- MST Performance Overview -->
                <div class="card">
                    <div class="card-header">
                        <h5>MID Performance Overview</h5>
                        <div class="filter-container">
                            <select id="classFilter" onchange="window.location.href='?class=' + this.value">
                                <?php foreach ($classes as $id => $class_name) { ?>
                                    <option value="<?php echo $id; ?>" <?php echo $selected_class_id == $id ? 'selected' : ''; ?>><?php echo htmlspecialchars($class_name); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="mstPerformanceChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Syllabus Coverage -->
                <div class="card">
                    <div class="card-header">
                        <h5>Syllabus Coverage</h5>
                    </div>
                    <div class="card-body">
                        <div class="chart-container">
                            <canvas id="syllabusCoverageChart"></canvas>
                        </div>
                    </div>
                </div>

                <!-- Teacher Performance -->
                <div class="card">
                    <div class="card-header">
                        <h5>Teacher Performance</h5>
                    </div>
                    <div class="card-body">
                        <table>
                            <thead>
                                <tr>
                                    <th>Teacher</th>
                                    <th>Course</th>
                                    <th>Timeline</th>
                                    <th>Syllabus Status</th>
                                    <th>Mid1 Avg</th>
                                    <th>Mid2 Avg</th>
                                    <th>ICA Avg</th>
                                    <th>Assignments</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $processed_rows = [];
                                while ($row = mysqli_fetch_assoc($progress_result)) {
                                    $key = $row['teacher_id'] . '_' . $row['course_name'] . '_' . $row['timeline'];
                                    if (!isset($processed_rows[$key])) {
                                        $completion = $row['avg_completion'];
                                        $colorClass = 'bg-danger';
                                        if ($completion >= 40 && $completion <= 79) $colorClass = 'bg-warning';
                                        elseif ($completion > 80) $colorClass = 'bg-success';
                                        $mid1_avg = isset($mst_data[$row['course_name']]['MST1']) ? $mst_data[$row['course_name']]['MST1'] : 0;
                                        $mid2_avg = isset($mst_data[$row['course_name']]['MST2']) ? $mst_data[$row['course_name']]['MST2'] : 0;
                                        $ica_avg = isset($ica_data[$row['course_name']]) ? $ica_data[$row['course_name']] : 0;
                                        $assignments = isset($teacher_assignments[$row['teacher_id']]) ? $teacher_assignments[$row['teacher_id']] : 0;
                                        ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['teacher_name']); ?></td>
                                            <td><?php echo htmlspecialchars($row['course_name']); ?></td>
                                            <td><?php echo htmlspecialchars(ucfirst($row['timeline'])); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <div class="progress flex-grow-1">
                                                        <div class="progress-bar <?php echo $colorClass; ?>" role="progressbar" style="width: <?php echo $completion; ?>%" aria-valuenow="<?php echo $completion; ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                                    </div>
                                                    <span class="ms-2"><?php echo $completion; ?>%</span>
                                                </div>
                                            </td>
                                            <td><?php echo $mid1_avg ? $mid1_avg . '%' : '0%'; ?></td>
                                            <td><?php echo $mid2_avg ? $mid2_avg . '%' : '0%'; ?></td>
                                            <td><?php echo $ica_avg ? $ica_avg . '%' : '0%'; ?></td>
                                            <td><?php echo $assignments; ?>/15</td>
                                        </tr>
                                        <?php
                                        $processed_rows[$key] = true;
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Pending Alerts -->
                <div class="card">
                    <div class="card-header">
                        <h5>Pending Alerts</h5>
                    </div>
                    <div class="card-body">
                        <table>
                            <tr>
                                <th>Teacher</th>
                                <th>Message</th>
                            </tr>
                            <?php while ($alert = mysqli_fetch_assoc($alerts_result)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($alert['name']); ?></td>
                                    <td><?php echo htmlspecialchars($alert['message']); ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                    </div>
                </div>

                <p>
                    <a href="track_teachers.php">Track Teachers</a> |
                    <a href="send_alerts.php">Send Alerts</a> |
                    <a href="view_reports.php">View Reports</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }

        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
        }

        // MST Performance Chart with adjusted bar size
        const mstPerformanceCtx = document.getElementById('mstPerformanceChart').getContext('2d');
        const mstPerformanceChart = new Chart(mstPerformanceCtx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($filtered_subjects); ?>,
                datasets: [
                    {
                        label: 'MID1 Average',
                        data: <?php echo json_encode(array_map(function($subject) use ($filtered_mst_data) { return $filtered_mst_data[$subject]['MST1'] ?? 0; }, $filtered_subjects)); ?>,
                        backgroundColor: 'rgba(74, 144, 226, 0.7)',
                        borderColor: 'rgba(74, 144, 226, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'MID2 Average',
                        data: <?php echo json_encode(array_map(function($subject) use ($filtered_mst_data) { return $filtered_mst_data[$subject]['MST2'] ?? 0; }, $filtered_subjects)); ?>,
                        backgroundColor: 'rgba(245, 166, 35, 0.7)',
                        borderColor: 'rgba(245, 166, 35, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Average Marks (%)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Subjects'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.raw + '%';
                                return label;
                            }
                        }
                    },
                    legend: {
                        position: 'top'
                    }
                },
                barPercentage: 0.5,         // Adjusts the width of individual bars
                categoryPercentage: 0.6     // Adjusts the spacing between bar groups
            }
        });

        // Syllabus Coverage Chart with multiple lines
        const syllabusCoverageCtx = document.getElementById('syllabusCoverageChart').getContext('2d');
        const syllabusCoverageChart = new Chart(syllabusCoverageCtx, {
            type: 'line',
            data: {
                labels: ['Mid1', 'Mid2', 'Final'],
                datasets: [
                    <?php foreach ($subjects as $subject) { ?>
                        {
                            label: '<?php echo $subject; ?>',
                            data: [
                                <?php echo isset($syllabus_data[$subject]['Mid1']) ? $syllabus_data[$subject]['Mid1'] : 0; ?>,
                                <?php echo isset($syllabus_data[$subject]['Mid2']) ? $syllabus_data[$subject]['Mid2'] : 0; ?>,
                                <?php echo isset($syllabus_data[$subject]['Final']) ? $syllabus_data[$subject]['Final'] : 0; ?>
                            ],
                            borderColor: 'rgba(<?php echo rand(0, 255) . ', ' . rand(0, 255) . ', ' . rand(0, 255) . ', 1'; ?>)',
                            backgroundColor: 'rgba(<?php echo rand(0, 255) . ', ' . rand(0, 255) . ', ' . rand(0, 255) . ', 0.1'; ?>)',
                            tension: 0.4,
                            fill: true
                        },
                    <?php } ?>
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        title: {
                            display: true,
                            text: 'Syllabus Covered (%)'
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                let label = context.dataset.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                label += context.raw + '%';
                                return label;
                            }
                        }
                    },
                    legend: {
                        position: 'top'
                    }
                }
            }
        });
    </script>
</body>
</html>