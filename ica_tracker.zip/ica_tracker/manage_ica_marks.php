<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: login.php');
    exit;
}

$teacher_id = (int)$_SESSION['user_id'];

// Fetch all classes for the teacher
$classes_result = mysqli_query($conn, "SELECT id, class_name FROM classes WHERE teacher_id='$teacher_id'");
if ($classes_result === false) {
    die("Classes Query failed: " . mysqli_error($conn));
}

// Get selected class from dropdown
$selected_class_id = isset($_GET['class_id']) ? (int)$_GET['class_id'] : null;

// Map class_id to subject
$class_subject_map = [
    1 => 'ADSA',    // CSEDS 3rd Year
    2 => 'DBMS',    // CSEDS 2nd Year
    3 => 'DAA'      // CE 2nd Year
];

// Fetch students based on selected class, sorted by roll_number
$students_query = "SELECT s.name, s.roll_number, c.class_name, s.class_id 
                   FROM students s 
                   JOIN classes c ON s.class_id = c.id 
                   WHERE s.teacher_id='$teacher_id'";
if ($selected_class_id) {
    $students_query .= " AND s.class_id = '$selected_class_id'";
}
$students_query .= " ORDER BY s.roll_number ASC";
$students_result = mysqli_query($conn, $students_query);
if ($students_result === false) {
    die("Students Query failed: " . mysqli_error($conn));
}
$students = [];
while ($student = mysqli_fetch_assoc($students_result)) {
    $students[$student['class_id']][] = $student;
}

// Check completion status
$mid1_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid1' AND component_type='mid1' AND marks > 0"))['count'] > 0;
$mid2_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid2' AND component_type='mid2' AND marks > 0"))['count'] > 0;
$final_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='final_ica' AND component_type IN ('project_presentation', 'lab_exam', 'class_participation') AND marks > 0"))['count'] > 0;

// Handle form submissions
$selected_timeline = isset($_POST['timeline']) ? $_POST['timeline'] : 'mid1';
$num_experiments = isset($_POST['num_experiments']) ? (int)$_POST['num_experiments'] : 0;
$num_assignments = isset($_POST['num_assignments']) ? (int)$_POST['num_assignments'] : 0;
$subject = isset($_POST['subject']) ? mysqli_real_escape_string($conn, $_POST['subject']) : (isset($class_subject_map[$selected_class_id]) ? $class_subject_map[$selected_class_id] : '');

// Determine starting experiment number for Mid2 based on Mid1
$mid1_exp_count = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid1' AND component_type LIKE 'experiment_%' AND student_name=(SELECT student_name FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid1' LIMIT 1)"))['count'];
$start_exp = ($selected_timeline == 'mid1') ? 1 : ($selected_timeline == 'mid2' && $mid1_completed ? ($mid1_exp_count + 1) : 1);
$max_experiments = 15; // Set maximum experiments to 15

// Handle "Add Columns"
if (isset($_POST['add_column']) && !empty($subject)) {
    $compulsory_type = ($selected_timeline == 'mid1' || $selected_timeline == 'mid2') ? $selected_timeline : 'final_ica';
    foreach ($students as $class_students) {
        foreach ($class_students as $student) {
            $query = "INSERT IGNORE INTO ica_marks (teacher_id, subject, timeline, student_name, component_type, marks) 
                      VALUES (?, ?, ?, ?, ?, 0)";
            $stmt = mysqli_prepare($conn, $query);
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "issss", $teacher_id, $subject, $selected_timeline, $student['name'], $compulsory_type);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
                die("Prepare failed: " . mysqli_error($conn));
            }
        }
    }
    if ($selected_timeline != 'final_ica' && $num_experiments > 0 && $num_experiments <= $max_experiments) {
        for ($i = $start_exp; $i < $start_exp + $num_experiments; $i++) {
            $component_type = "experiment_$i";
            foreach ($students as $class_students) {
                foreach ($class_students as $student) {
                    $query = "INSERT IGNORE INTO ica_marks (teacher_id, subject, timeline, student_name, component_type, marks) 
                              VALUES (?, ?, ?, ?, ?, 0)";
                    $stmt = mysqli_prepare($conn, $query);
                    if ($stmt) {
                        mysqli_stmt_bind_param($stmt, "issss", $teacher_id, $subject, $selected_timeline, $student['name'], $component_type);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } else {
                        die("Prepare failed: " . mysqli_error($conn));
                    }
                }
            }
        }
    }
    if ($selected_timeline != 'final_ica' && $num_assignments > 0) {
        for ($i = 1; $i <= $num_assignments; $i++) {
            $component_type = "assignment_$i";
            foreach ($students as $class_students) {
                foreach ($class_students as $student) {
                    $query = "INSERT IGNORE INTO ica_marks (teacher_id, subject, timeline, student_name, component_type, marks) 
                              VALUES (?, ?, ?, ?, ?, 0)";
                    $stmt = mysqli_prepare($conn, $query);
                    if ($stmt) {
                        mysqli_stmt_bind_param($stmt, "issss", $teacher_id, $subject, $selected_timeline, $student['name'], $component_type);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } else {
                        die("Prepare failed: " . mysqli_error($conn));
                    }
                }
            }
        }
    } elseif ($selected_timeline == 'final_ica') {
        $components = ['project_presentation', 'lab_exam', 'class_participation'];
        foreach ($components as $component_type) {
            foreach ($students as $class_students) {
                foreach ($class_students as $student) {
                    $query = "INSERT IGNORE INTO ica_marks (teacher_id, subject, timeline, student_name, component_type, marks) 
                              VALUES (?, ?, ?, ?, ?, 0)";
                    $stmt = mysqli_prepare($conn, $query);
                    if ($stmt) {
                        mysqli_stmt_bind_param($stmt, "issss", $teacher_id, $subject, $selected_timeline, $student['name'], $component_type);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } else {
                        die("Prepare failed: " . mysqli_error($conn));
                    }
                }
            }
        }
    }
}

// Fetch data for the selected timeline
$ica_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline IN ('mid1', 'mid2', 'final_ica') ORDER BY subject, student_name");
if ($ica_data === false) {
    die("ICA Data Query failed: " . mysqli_error($conn));
}
$ica_students = [];
while ($row = mysqli_fetch_assoc($ica_data)) {
    $ica_students[$row['student_name']][$row['timeline']][$row['component_type']] = ['id' => $row['id'], 'marks' => $row['marks']];
}

// Handle "Submit Marks"
if (isset($_POST['submit_marks']) && isset($_POST['marks'])) {
    foreach ($_POST['marks'] as $id => $marks) {
        $marks = (int)$marks;
        $max_marks = ($selected_timeline == 'final_ica' && (strpos($id, 'lab_exam') !== false || strpos($id, 'class_participation') !== false)) ? 5 : 10;
        $marks = min($marks, $max_marks); // Cap marks at the maximum allowed
        $query = "UPDATE ica_marks SET marks=? WHERE id=? AND teacher_id=? AND timeline=?";
        $stmt = mysqli_prepare($conn, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "iiss", $marks, $id, $teacher_id, $selected_timeline);
            $success = mysqli_stmt_execute($stmt);
            if (!$success) {
                die("Update failed for id $id: " . mysqli_error($conn));
            }
            mysqli_stmt_close($stmt);
        } else {
            die("Prepare failed: " . mysqli_error($conn));
        }
    }
    // Refresh data after submission
    $ica_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline IN ('mid1', 'mid2', 'final_ica') ORDER BY subject, student_name");
    if ($ica_data === false) {
        die("ICA Data Query failed: " . mysqli_error($conn));
    }
    $ica_students = [];
    while ($row = mysqli_fetch_assoc($ica_data)) {
        $ica_students[$row['student_name']][$row['timeline']][$row['component_type']] = ['id' => $row['id'], 'marks' => $row['marks']];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage ICA Marks - ICA Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            line-height: 1.6;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #2c3e50 0%, #4a4a4a 100%);
            color: #e0e0e0;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #333333;
            color: #fff;
            padding: 20px;
            position: fixed;
            height: 100%;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: width 0.3s;
        }

        .sidebar h2 {
            font-size: 1.8rem;
            margin-bottom: 30px;
            text-align: center;
            color: #ecf0f1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #ecf0f1;
            text-decoration: none;
            padding: 12px 15px;
            margin: 10px 0;
            border-radius: 8px;
            transition: background 0.3s, transform 0.2s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #A6192E;
            transform: translateX(5px);
        }

        .sidebar a i {
            margin-right: 12px;
            font-size: 1.2rem;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s, width 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .header h2 {
            font-size: 2rem;
            color: #A6192E;
            font-weight: 600;
        }

        .theme-toggle {
            background: #A6192E;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s, transform 0.2s;
        }

        .theme-toggle:hover {
            background: #7f1422;
            transform: scale(1.05);
        }

        .class-filter {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        form {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        select, input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            background: #f9f9f9;
            transition: border-color 0.3s;
        }

        select:focus, input:focus {
            border-color: #A6192E;
            outline: none;
        }

        button {
            padding: 12px 25px;
            background: #A6192E;
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s, transform 0.2s;
        }

        button:hover {
            background: #7f1422;
            transform: scale(1.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        th, td {
            padding: 15px;
            text-align: center;
            border-bottom: 1px solid #e0e0e0;
        }

        th {
            background: #A6192E;
            color: #fff;
            font-weight: 600;
        }

        body.dark-mode th {
            background: #4a4a4a;
        }

        td input {
            width: 80px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }

        tr:hover {
            background: #f9f9f9;
        }

        body.dark-mode tr:hover {
            background: #5a5a5a;
        }

        a {
            color: #A6192E;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        a:hover {
            color: #7f1422;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .sidebar h2, .sidebar a span {
                display: none;
            }

            .sidebar a i {
                margin-right: 0;
            }

            .main-content {
                margin-left: 70px;
                width: calc(100% - 70px);
            }
        }
    </style>
    <script>
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }

        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
        }

        // Function to download CSV
        function downloadCSV() {
            let csv = 'Student Name,Roll Number,Mid1,Mid2,Assignment,Lab Exam,Experiment,Class Participation,Project/Presentation,Total\n';
            const table = document.querySelector('table');
            const rows = table.getElementsByTagName('tr');
            for (let i = 1; i < rows.length; i++) {
                const cols = rows[i].getElementsByTagName('td');
                const row = [
                    cols[0].textContent,
                    cols[1].textContent,
                    cols[2].textContent,
                    cols[3].textContent,
                    cols[4].textContent,
                    cols[5].textContent,
                    cols[6].textContent,
                    cols[7].textContent,
                    cols[8].textContent,
                    cols[9].textContent
                ];
                csv += row.join(',') + '\n';
            }
            const csvFile = new Blob([csv], { type: 'text/csv' });
            const downloadLink = document.createElement('a');
            downloadLink.download = 'final_ica_marks.csv';
            downloadLink.href = window.URL.createObjectURL(csvFile);
            downloadLink.style.display = 'none';
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
        }

        // Function to download PDF (using html2pdf library)
        function downloadPDF() {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            doc.text("Final ICA Marks", 10, 10);
            const table = document.querySelector('table');
            doc.autoTable({ html: table });
            doc.save('final_ica_marks.pdf');
        }
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>ICA Tracker</h2>
            <a href="teacher_dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
            <a href="update_progress.php"><i class="fas fa-chart-line"></i> <span>Update Progress</span></a>
            <a href="manage_ica_marks.php" class="active"><i class="fas fa-book"></i> <span>Manage ICA Marks</span></a>
            <a href="view_alerts.php"><i class="fas fa-bell"></i> <span>View Alerts</span></a>
            <a href="view_reports.php"><i class="fas fa-file-alt"></i> <span>View Reports</span></a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
                <button class="theme-toggle" onclick="toggleTheme()">Toggle Theme</button>
            </div>
            <div class="container">
                <!-- Class Filter Dropdown -->
                <div class="class-filter">
                    <form method="GET">
                        <label>Select Class</label>
                        <select name="class_id" onchange="this.form.submit()">
                            <option value="">All Classes</option>
                            <?php 
                            mysqli_data_seek($classes_result, 0);
                            while ($class = mysqli_fetch_assoc($classes_result)) { ?>
                                <option value="<?php echo $class['id']; ?>" <?php echo $selected_class_id == $class['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($class['class_name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                    </form>
                </div>

                <h2>Manage ICA Marks</h2>

                <!-- ICA Marks Form -->
                <form method="POST">
                    <label>Select Timeline</label>
                    <select name="timeline" onchange="this.form.submit()" required>
                        <option value="mid1" <?php echo $selected_timeline == 'mid1' ? 'selected' : ''; ?>>Mid1</option>
                        <option value="mid2" <?php echo $selected_timeline == 'mid2' ? 'selected' : ''; ?> <?php echo !$mid1_completed ? 'disabled' : ''; ?>>Mid2</option>
                        <option value="final_ica" <?php echo $selected_timeline == 'final_ica' ? 'selected' : ''; ?> <?php echo !($mid1_completed && $mid2_completed) ? 'disabled' : ''; ?>>Final ICA</option>
                    </select>

                    <?php if ($selected_timeline == 'mid1' || ($selected_timeline == 'mid2' && $mid1_completed) || ($selected_timeline == 'final_ica' && $mid1_completed && $mid2_completed)) { ?>
                        <label>Select Subject</label>
                        <select name="subject" required>
                            <option value="">Select a Class First</option>
                            <?php 
                            if ($selected_class_id && isset($class_subject_map[$selected_class_id])) {
                                $subject_option = $class_subject_map[$selected_class_id];
                                echo "<option value='$subject_option' " . ($subject == $subject_option ? 'selected' : '') . ">$subject_option</option>";
                            }
                            ?>
                        </select>
                        <?php if ($selected_timeline != 'final_ica') { ?>
                            <label>Number of Experiments</label>
                            <input type="number" name="num_experiments" min="0" max="<?php echo $max_experiments; ?>" value="<?php echo $num_experiments; ?>" required>
                            <label>Number of Assignments</label>
                            <input type="number" name="num_assignments" min="0" max="10" value="<?php echo $num_assignments; ?>" required>
                        <?php } ?>
                        <button type="submit" name="add_column">Add Components</button>
                    <?php } else { ?>
                        <p>Please complete the previous timeline(s) before proceeding.</p>
                    <?php } ?>
                </form>

                <?php if (isset($_POST['add_column']) && !isset($_POST['submit_marks'])): ?>
                    <?php if ($selected_timeline != 'final_ica' && ($num_experiments > 0 || $num_assignments > 0)): ?>
                        <!-- Temporary Experiments Table for Mid1/Mid2 -->
                        <h4><?php echo ucfirst($selected_timeline); ?> Components</h4>
                        <form method="POST">
                            <input type="hidden" name="timeline" value="<?php echo $selected_timeline; ?>">
                            <input type="hidden" name="num_experiments" value="<?php echo $num_experiments; ?>">
                            <input type="hidden" name="num_assignments" value="<?php echo $num_assignments; ?>">
                            <table>
                                <tr>
                                    <th>Student</th>
                                    <th><?php echo ucfirst($selected_timeline); ?> Marks (10)</th>
                                    <?php for ($i = $start_exp; $i < $start_exp + $num_experiments; $i++): ?>
                                        <th>Experiment <?php echo $i; ?> (10)</th>
                                    <?php endfor; ?>
                                    <?php for ($i = 1; $i <= $num_assignments; $i++): ?>
                                        <th>Assignment <?php echo $i; ?> (10)</th>
                                    <?php endfor; ?>
                                </tr>
                                <?php foreach ($students as $class_students): ?>
                                    <?php foreach ($class_students as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['name']); ?></td>
                                            <td><input type="number" name="marks[<?php echo $ica_students[$student['name']][$selected_timeline][$selected_timeline]['id'] ?? ''; ?>]" value="<?php echo $ica_students[$student['name']][$selected_timeline][$selected_timeline]['marks'] ?? 0; ?>" min="0" max="10" required></td>
                                            <?php for ($i = $start_exp; $i < $start_exp + $num_experiments; $i++): ?>
                                                <?php $exp_key = "experiment_$i"; ?>
                                                <td><input type="number" name="marks[<?php echo $ica_students[$student['name']][$selected_timeline][$exp_key]['id'] ?? ''; ?>]" value="<?php echo $ica_students[$student['name']][$selected_timeline][$exp_key]['marks'] ?? 0; ?>" min="0" max="10" required></td>
                                            <?php endfor; ?>
                                            <?php for ($i = 1; $i <= $num_assignments; $i++): ?>
                                                <?php $ass_key = "assignment_$i"; ?>
                                                <td><input type="number" name="marks[<?php echo $ica_students[$student['name']][$selected_timeline][$ass_key]['id'] ?? ''; ?>]" value="<?php echo $ica_students[$student['name']][$selected_timeline][$ass_key]['marks'] ?? 0; ?>" min="0" max="10" required></td>
                                            <?php endfor; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            </table>
                            <button type="submit" name="submit_marks">Submit Marks</button>
                        </form>
                    <?php elseif ($selected_timeline == 'final_ica'): ?>
                        <!-- Final ICA Components -->
                        <h4>Final ICA Components</h4>
                        <form method="POST">
                            <input type="hidden" name="timeline" value="<?php echo $selected_timeline; ?>">
                            <table>
                                <tr>
                                    <th>Student</th>
                                    <th>Project/Presentation (10)</th>
                                    <th>Lab Exam (5)</th>
                                    <th>Class Participation (5)</th>
                                </tr>
                                <?php foreach ($students as $class_students): ?>
                                    <?php foreach ($class_students as $student): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($student['name']); ?></td>
                                            <td><input type="number" name="marks[<?php echo $ica_students[$student['name']]['final_ica']['project_presentation']['id'] ?? ''; ?>]" value="<?php echo $ica_students[$student['name']]['final_ica']['project_presentation']['marks'] ?? 0; ?>" min="0" max="10" required></td>
                                            <td><input type="number" name="marks[<?php echo $ica_students[$student['name']]['final_ica']['lab_exam']['id'] ?? ''; ?>]" value="<?php echo $ica_students[$student['name']]['final_ica']['lab_exam']['marks'] ?? 0; ?>" min="0" max="5" required></td>
                                            <td><input type="number" name="marks[<?php echo $ica_students[$student['name']]['final_ica']['class_participation']['id'] ?? ''; ?>]" value="<?php echo $ica_students[$student['name']]['final_ica']['class_participation']['marks'] ?? 0; ?>" min="0" max="5" required></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            </table>
                            <button type="submit" name="submit_marks">Submit Marks</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (isset($_POST['submit_marks'])): ?>
                    <?php if ($selected_timeline == 'mid1'): ?>
                        <!-- Updated Mid1 Marks Table -->
                        <h3>Updated Mid1 Marks</h3>
                        <?php
                        $all_ica_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid1' ORDER BY student_name");
                        if ($all_ica_data === false) {
                            die("Mid1 Data Query failed: " . mysqli_error($conn));
                        }
                        $all_ica_students = [];
                        while ($row = mysqli_fetch_assoc($all_ica_data)) {
                            $all_ica_students[$row['student_name']][$row['component_type']] = $row['marks'];
                        }
                        ?>
                        <table>
                            <tr>
                                <th>Name</th>
                                <th>Roll Number</th>
                                <th>Class</th>
                                <th>Mid1 Marks (10)</th>
                                <th>Avg Experiments</th>
                                <th>Avg Assignments</th>
                            </tr>
                            <?php foreach ($students as $class_students): ?>
                                <?php foreach ($class_students as $student): ?>
                                    <?php
                                    $mid1Marks = isset($all_ica_students[$student['name']]['mid1']) ? $all_ica_students[$student['name']]['mid1'] : 0;

                                    // Calculate average for experiments
                                    $expMarks = [];
                                    foreach (['experiment_1', 'experiment_2', 'experiment_3', 'experiment_4', 'experiment_5', 'experiment_6', 'experiment_7', 'experiment_8', 'experiment_9', 'experiment_10', 'experiment_11', 'experiment_12', 'experiment_13', 'experiment_14', 'experiment_15'] as $exp) {
                                        $expMarks[] = isset($all_ica_students[$student['name']][$exp]) ? (float)$all_ica_students[$student['name']][$exp] : 0;
                                    }
                                    $experimentAvg = array_sum($expMarks) > 0 ? number_format(array_sum(array_filter($expMarks)) / count(array_filter($expMarks)), 2) : 0;

                                    // Calculate average for assignments
                                    $assMarks = [];
                                    foreach (['assignment_1', 'assignment_2'] as $ass) {
                                        $assMarks[] = isset($all_ica_students[$student['name']][$ass]) ? (float)$all_ica_students[$student['name']][$ass] : 0;
                                    }
                                    $assignmentAvg = array_sum($assMarks) > 0 ? number_format(array_sum(array_filter($assMarks)) / count(array_filter($assMarks)), 2) : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                                        <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                                        <td><?php echo htmlspecialchars($student['class_name']); ?></td>
                                        <td><?php echo $mid1Marks > 0 ? $mid1Marks : '-'; ?></td>
                                        <td><?php echo $experimentAvg > 0 ? $experimentAvg : '-'; ?></td>
                                        <td><?php echo $assignmentAvg > 0 ? $assignmentAvg : '-'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </table>
                    <?php elseif ($selected_timeline == 'mid2'): ?>
                        <!-- Updated Mid2 Marks Table -->
                        <h3>Updated Mid2 Marks</h3>
                        <?php
                        $all_ica_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid2' ORDER BY student_name");
                        if ($all_ica_data === false) {
                            die("Mid2 Data Query failed: " . mysqli_error($conn));
                        }
                        $all_ica_students = [];
                        while ($row = mysqli_fetch_assoc($all_ica_data)) {
                            $all_ica_students[$row['student_name']][$row['component_type']] = $row['marks'];
                        }
                        ?>
                        <table>
                            <tr>
                                <th>Name</th>
                                <th>Roll Number</th>
                                <th>Class</th>
                                <th>Mid2 Marks (10)</th>
                                <th>Avg Experiments</th>
                                <th>Avg Assignments</th>
                            </tr>
                            <?php foreach ($students as $class_students): ?>
                                <?php foreach ($class_students as $student): ?>
                                    <?php
                                    $mid2Marks = isset($all_ica_students[$student['name']]['mid2']) ? $all_ica_students[$student['name']]['mid2'] : 0;

                                    // Calculate average for experiments starting from $start_exp
                                    $expMarks = [];
                                    for ($i = $start_exp; $i < $start_exp + $num_experiments; $i++) {
                                        $exp_key = "experiment_$i";
                                        $expMarks[] = isset($all_ica_students[$student['name']][$exp_key]) ? (float)$all_ica_students[$student['name']][$exp_key] : 0;
                                    }
                                    $experimentAvg = array_sum($expMarks) > 0 ? number_format(array_sum(array_filter($expMarks)) / count(array_filter($expMarks)), 2) : 0;

                                    // Calculate average for assignments
                                    $assMarks = [];
                                    for ($i = 1; $i <= $num_assignments; $i++) {
                                        $ass_key = "assignment_$i";
                                        $assMarks[] = isset($all_ica_students[$student['name']][$ass_key]) ? (float)$all_ica_students[$student['name']][$ass_key] : 0;
                                    }
                                    $assignmentAvg = array_sum($assMarks) > 0 ? number_format(array_sum(array_filter($assMarks)) / count(array_filter($assMarks)), 2) : 0;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                                        <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                                        <td><?php echo htmlspecialchars($student['class_name']); ?></td>
                                        <td><?php echo $mid2Marks > 0 ? $mid2Marks : '-'; ?></td>
                                        <td><?php echo $experimentAvg > 0 ? $experimentAvg : '-'; ?></td>
                                        <td><?php echo $assignmentAvg > 0 ? $assignmentAvg : '-'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </table>
                    <?php elseif ($selected_timeline == 'final_ica'): ?>
                        <!-- Main Table for Updated Final ICA Marks -->
                        <h3>Updated Final ICA Marks</h3>
                        <?php
                        $all_ica_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline IN ('mid1', 'mid2', 'final_ica') ORDER BY student_name");
                        if ($all_ica_data === false) {
                            die("All ICA Data Query failed: " . mysqli_error($conn));
                        }
                        $all_ica_students = [];
                        while ($row = mysqli_fetch_assoc($all_ica_data)) {
                            $all_ica_students[$row['student_name']][$row['timeline']][$row['component_type']] = $row['marks'];
                        }
                        ?>
                        <table>
                            <tr>
                                <th>Student Name</th>
                                <th>Roll Number</th>
                                <th>Mid1 (10)</th>
                                <th>Mid2 (10)</th>
                                <th>Assignment (5)</th>
                                <th>Lab Exam (5)</th>
                                <th>Experiment (5)</th>
                                <th>Class Participation (5)</th>
                                <th>Project/Presentation (10)</th>
                                <th>Total (50)</th>
                            </tr>
                            <?php foreach ($students as $class_students): ?>
                                <?php foreach ($class_students as $student): ?>
                                    <?php
                                    $mid1Marks = isset($all_ica_students[$student['name']]['mid1']['mid1']) ? $all_ica_students[$student['name']]['mid1']['mid1'] : 0;
                                    $mid2Marks = isset($all_ica_students[$student['name']]['mid2']['mid2']) ? $all_ica_students[$student['name']]['mid2']['mid2'] : 0;

                                    // Calculate average for assignments
                                    $assMarks = [];
                                    foreach (['mid1', 'mid2'] as $timeline) {
                                        if (isset($all_ica_students[$student['name']][$timeline])) {
                                            foreach ($all_ica_students[$student['name']][$timeline] as $type => $marks) {
                                                if (preg_match('/^assignment_\d+$/', $type)) {
                                                    $assMarks[] = (float)$marks;
                                                }
                                            }
                                        }
                                    }
                                    $assignmentAvg = !empty($assMarks) ? number_format(array_sum($assMarks) / count($assMarks), 2) : 0;
                                    $assignmentMarks = min($assignmentAvg, 5); // Cap at 5

                                    // Calculate average for experiments and scale down to 5 marks
                                    $expMarks = [];
                                    foreach (['mid1', 'mid2'] as $timeline) {
                                        if (isset($all_ica_students[$student['name']][$timeline])) {
                                            foreach ($all_ica_students[$student['name']][$timeline] as $type => $marks) {
                                                if (preg_match('/^experiment_\d+$/', $type)) {
                                                    $expMarks[] = (float)$marks;
                                                }
                                            }
                                        }
                                    }
                                    $experimentAvg = !empty($expMarks) ? number_format(array_sum($expMarks) / count($expMarks), 2) : 0;
                                    $experimentMarks = min($experimentAvg * (5 / 10), 5); // Scale down to 5 marks (max 10 -> 5)

                                    $labExam = isset($all_ica_students[$student['name']]['final_ica']['lab_exam']) ? $all_ica_students[$student['name']]['final_ica']['lab_exam'] : 0;
                                    $classPart = isset($all_ica_students[$student['name']]['final_ica']['class_participation']) ? $all_ica_students[$student['name']]['final_ica']['class_participation'] : 0;
                                    $projectMarks = isset($all_ica_students[$student['name']]['final_ica']['project_presentation']) ? $all_ica_students[$student['name']]['final_ica']['project_presentation'] : 0;

                                    $totalMarks = $mid1Marks + $mid2Marks + $assignmentMarks + $labExam + $experimentMarks + $classPart + $projectMarks;
                                    ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                                        <td><?php echo htmlspecialchars($student['roll_number']); ?></td>
                                        <td><?php echo $mid1Marks > 0 ? $mid1Marks : '-'; ?></td>
                                        <td><?php echo $mid2Marks > 0 ? $mid2Marks : '-'; ?></td>
                                        <td><?php echo $assignmentMarks > 0 ? $assignmentMarks : '-'; ?></td>
                                        <td><?php echo $labExam > 0 ? $labExam : '-'; ?></td>
                                        <td><?php echo $experimentMarks > 0 ? $experimentMarks : '-'; ?></td>
                                        <td><?php echo $classPart > 0 ? $classPart : '-'; ?></td>
                                        <td><?php echo $projectMarks > 0 ? $projectMarks : '-'; ?></td>
                                        <td><?php echo $totalMarks > 0 ? number_format($totalMarks, 2) : '-/50'; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </table>
                        <!-- Download Options -->
                        <div>
                            <button onclick="downloadCSV()">Download CSV</button>
                            
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
            </div>
        </div>
    </div>
</body>
</html>