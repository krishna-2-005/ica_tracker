<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'program_chair') {
    header('Location: login.php');
    exit;
}

$progress_query = "SELECT u.name, AVG(sp.completion_percentage) as avg_completion
                   FROM users u
                   LEFT JOIN syllabus_progress sp ON u.id = sp.teacher_id
                   WHERE u.role='teacher'
                   GROUP BY u.id";
$progress_result = mysqli_query($conn, $progress_query);

// Generate PDF
if (isset($_GET['export']) && $_GET['export'] == 'pdf') {
    header('Content-Type: application/pdf');
    header('Content-Disposition: atlachment; filename="teachers_report.pdf"');

    $output = "%PDF-1.4\n";
    $output .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
    $output .= "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n";
    $output .= "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R >>\nendobj\n";
    $output .= "4 0 obj\n<< /Length 5 0 R >>\nstream\n";
    $output .= "BT /F1 12 Tf 50 800 Td (Teachers Progress Report) Tj ET\n";
    $output .= "BT /F1 12 Tf 50 780 Td (Teacher) Tj 200 780 Td (Average Completion %) Tj ET\n";

    $y = 760;
    mysqli_data_seek($progress_result, 0);
    while ($row = mysqli_fetch_assoc($progress_result)) {
        $output .= "BT /F1 12 Tf 50 $y Td ({$row['name']}) Tj 200 $y Td (" . round($row['avg_completion'], 2) . "%) Tj ET\n";
        $y -= 20;
    }
    $output .= "endstream\nendobj\n";
    $output .= "5 0 obj\n" . strlen($output) . "\nendobj\n";
    $output .= "6 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";
    $output .= "xref\n0 7\n0000000000 65535 f \n0000000010 00000 n \n0000000075 00000 n \n0000000120 00000 n \n0000000175 00000 n \n0000000290 00000 n \n0000000350 00000 n \ntrailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n400\n%%EOF";

    echo $output;
    exit;
}

// Generate CSV
if (isset($_GET['export']) && $_GET['export'] == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="teachers_report.csv"');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Teacher', 'Average Completion %']);
    mysqli_data_seek($progress_result, 0);
    while ($row = mysqli_fetch_assoc($progress_result)) {
        fputcsv($output, [$row['name'], round($row['avg_completion'], 2)]);
    }
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Program Chair Reports</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h2>Teachers' Progress Reports</h2>
        <table>
            <tr><th>Teacher</th><th>Average Completion (%)</th></tr>
            <?php while ($row = mysqli_fetch_assoc($progress_result)) { ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo round($row['avg_completion'], 2); ?>%</td>
                </tr>
            <?php } ?>
        </table>
        <p>
            <a href="?export=pdf">Download PDF</a> |
            <a href="?export=csv">Download CSV</a>
        </p>
        <p><a href="program_dashboard.php">Back to Dashboard</a></p>
    </div>
</body>
</html>