<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'program_chair') {
    header('Location: login.php');
    exit;
}

// Check for filter parameter
$filter = isset($_GET['filter']) && $_GET['filter'] === 'low' ? 'low' : 'all';

// Fetch students based on filter
if ($filter === 'low') {
    $students_query = "
        SELECT DISTINCT im.student_name, AVG(im.marks) AS avg_marks
        FROM ica_marks im
        JOIN users u ON im.teacher_id = u.id
        WHERE u.role = 'teacher'
        GROUP BY im.teacher_id, im.student_name
        HAVING AVG(im.marks) < 50
        ORDER BY avg_marks";
} else {
    $students_query = "
        SELECT DISTINCT im.student_name, AVG(im.marks) AS avg_marks
        FROM ica_marks im
        JOIN users u ON im.teacher_id = u.id
        WHERE u.role = 'teacher'
        GROUP BY im.teacher_id, im.student_name
        ORDER BY avg_marks";
}

$students_result = mysqli_query($conn, $students_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Progress - ICA Tracker</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: #F5F5F5;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #FFFFFF;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #E0E0E0;
        }
        th {
            background: #A6192E;
            color: #FFFFFF;
        }
        tr:hover {
            background: #F9F9F9;
        }
    </style>
</head>
<body>
    <h2>Student Progress</h2>
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Average Marks</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($students_result)) { ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['student_name']); ?></td>
                    <td><?php echo round($row['avg_marks'], 2); ?></td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</body>
</html>