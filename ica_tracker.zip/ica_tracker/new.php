<?php
session_start();
include 'db_connect.php';
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'teacher') {
    header('Location: login.php');
    exit;
}

$teacher_id = $_SESSION['user_id'];

// Determine current week
$semester_start = new DateTime('2025-04-01'); // Adjust this date
$today = new DateTime();
$interval = $semester_start->diff($today);
$days_passed = $interval->days;
$current_week = min(ceil($days_passed / 7), 14);

// Check timeline completion
$mid1_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid1'"))['count'] > 0;
$mid2_completed = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid2'"))['count'] > 0;

// Fetch subjects
$subjects_query = "SELECT subject_name FROM teacher_subjects WHERE teacher_id='$teacher_id'";
$subjects_result = mysqli_query($conn, $subjects_query);

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $timeline = $_POST['timeline'];

    if (isset($_POST['add_column'])) {
        $component_type = $_POST['component_type'];
        // Add a new column entry for each student (initially 0 marks)
        $students = ['Student1', 'Student2', 'Student3']; // Replace with actual student list
        foreach ($students as $student) {
            $query = "INSERT INTO ica_marks (teacher_id, subject, timeline, student_name, component_type, marks) 
                      VALUES ('$teacher_id', '$subject', '$timeline', '$student', '$component_type', 0)
                      ON DUPLICATE KEY UPDATE marks=marks";
            mysqli_query($conn, $query);
        }
    } elseif (isset($_POST['update_marks'])) {
        foreach ($_POST['marks'] as $id => $marks) {
            $marks = (int)$marks;
            $query = "UPDATE ica_marks SET marks='$marks' WHERE id='$id' AND teacher_id='$teacher_id'";
            mysqli_query($conn, $query);
        }
    }

    header('Location: manage_ica_marks.php');
    exit;
}

// Fetch ICA marks data
$mid1_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid1' ORDER BY subject, student_name");
$mid2_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='mid2' ORDER BY subject, student_name");
$final_data = mysqli_query($conn, "SELECT * FROM ica_marks WHERE teacher_id='$teacher_id' AND timeline='final' ORDER BY subject, student_name");

// Calculate averages for Final table
$experiment_avg = [];
$assignment_avg = [];
$students = [];
while ($row = mysqli_fetch_assoc($mid1_data)) {
    $students[$row['student_name']] = true;
    if ($row['component_type'] == 'experiment') {
        $experiment_avg[$row['student_name']][] = $row['marks'];
    } elseif ($row['component_type'] == 'assignment') {
        $assignment_avg[$row['student_name']][] = $row['marks'];
    }
}
mysqli_data_seek($mid1_data, 0);

while ($row = mysqli_fetch_assoc($mid2_data)) {
    if ($row['component_type'] == 'experiment') {
        $experiment_avg[$row['student_name']][] = $row['marks'];
    } elseif ($row['component_type'] == 'assignment') {
        $assignment_avg[$row['student_name']][] = $row['marks'];
    }
}
mysqli_data_seek($mid2_data, 0);

foreach ($experiment_avg as $student => $marks) {
    $experiment_avg[$student] = count($marks) > 0 ? array_sum($marks) / count($marks) : 0;
}
foreach ($assignment_avg as $student => $marks) {
    $assignment_avg[$student] = count($marks) > 0 ? array_sum($marks) / count($marks) : 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage ICA Marks - ICA Tracker</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            color: #333;
            line-height: 1.6;
            transition: background 0.3s, color 0.3s;
        }

        body.dark-mode {
            background: linear-gradient(135deg, #2c3e50 0%, #4a4a4a 100%);
            color: #e0e0e0;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: #fff;
            padding: 20px;
            position: fixed;
            height: 100%;
            box-shadow: 2px 0 10px rgba(0, 0, 0, 0.1);
            transition: width 0.3s;
        }

        .sidebar h2 {
            font-size: 1.8rem;
            margin-bottom: 30px;
            text-align: center;
            color: #ecf0f1;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            color: #ecf0f1;
            text-decoration: none;
            padding: 12px 15px;
            margin: 10px 0;
            border-radius: 8px;
            transition: background 0.3s, transform 0.2s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #A6192E;
            transform: translateX(5px);
        }

        .sidebar a i {
            margin-right: 12px;
            font-size: 1.2rem;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
            width: calc(100% - 250px);
            transition: margin-left 0.3s, width 0.3s;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        .header h2 {
            font-size: 2rem;
            color: #A6192E;
            font-weight: 600;
        }

        .theme-toggle {
            background: #A6192E;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s, transform 0.2s;
        }

        .theme-toggle:hover {
            background: #7f1422;
            transform: scale(1.05);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        form {
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #2c3e50;
        }

        select, input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            background: #f9f9f9;
            transition: border-color 0.3s;
        }

        select:focus, input:focus {
            border-color: #A6192E;
            outline: none;
        }

        button {
            padding: 12px 25px;
            background: #A6192E;
            color: #fff;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            font-size: 1rem;
            transition: background 0.3s, transform 0.2s;
        }

        button:hover {
            background: #7f1422;
            transform: scale(1.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }

        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        th {
            background: #A6192E;
            color: #fff;
            font-weight: 600;
        }

        body.dark-mode th {
            background: #4a4a4a;
        }

        tr:hover {
            background: #f9f9f9;
        }

        body.dark-mode tr:hover {
            background: #5a5a5a;
        }

        a {
            color: #A6192E;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }

        a:hover {
            color: #7f1422;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .sidebar h2, .sidebar a span {
                display: none;
            }

            .sidebar a i {
                margin-right: 0;
            }

            .main-content {
                margin-left: 70px;
                width: calc(100% - 70px);
            }
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <h2>ICA Tracker</h2>
            <a href="teacher_dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a>
            <a href="update_progress.php"><i class="fas fa-chart-line"></i> <span>Update Progress</span></a>
            <a href="manage_ica_marks.php" class="active"><i class="fas fa-book"></i> <span>Manage ICA Marks</span></a>
            <a href="view_alerts.php"><i class="fas fa-bell"></i> <span>View Alerts</span></a>
            <a href="view_reports.php"><i class="fas fa-file-alt"></i> <span>View Reports</span></a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> <span>Logout</span></a>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
                <button class="theme-toggle" onclick="toggleTheme()">Toggle Theme</button>
            </div>
            <div class="container">
                <h2>Manage ICA Marks (Week <?php echo $current_week; ?>)</h2>

                <?php if ($current_week <= 5 || $mid1_completed) { ?>
                    <!-- Mid1 Table -->
                    <h3>Mid1 Marks</h3>
                    <form method="POST">
                        <input type="hidden" name="timeline" value="mid1">
                        <label>Select Subject</label>
                        <select name="subject" required>
                            <option value="">Select a Subject</option>
                            <?php 
                            mysqli_data_seek($subjects_result, 0);
                            while ($subject = mysqli_fetch_assoc($subjects_result)) { ?>
                                <option value="<?php echo htmlspecialchars($subject['subject_name']); ?>">
                                    <?php echo htmlspecialchars($subject['subject_name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                        <label>Add ICA Component</label>
                        <select name="component_type">
                            <option value="experiment">Experiment</option>
                            <option value="assignment">Assignment</option>
                            <option value="group_assignment">Group Assignment</option>
                        </select>
                        <button type="submit" name="add_column">Add Column</button>
                    </form>
                    <form method="POST">
                        <input type="hidden" name="timeline" value="mid1">
                        <table>
                            <tr>
                                <th>Student</th>
                                <th>Mid1 (Compulsory)</th>
                                <?php 
                                $components = [];
                                while ($row = mysqli_fetch_assoc($mid1_data)) {
                                    if ($row['component_type'] != 'mid1') {
                                        $components[$row['component_type']] = true;
                                    }
                                }
                                mysqli_data_seek($mid1_data, 0);
                                foreach ($components as $type => $val) {
                                    echo "<th>" . ucfirst(str_replace('_', ' ', $type)) . "</th>";
                                }
                                ?>
                            </tr>
                            <?php 
                            $students = [];
                            while ($row = mysqli_fetch_assoc($mid1_data)) {
                                $students[$row['student_name']][$row['component_type']] = ['id' => $row['id'], 'marks' => $row['marks']];
                            }
                            foreach ($students as $student => $marks) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student); ?></td>
                                    <td><input type="number" name="marks[<?php echo $marks['mid1']['id']; ?>]" value="<?php echo $marks['mid1']['marks']; ?>" min="0" required></td>
                                    <?php foreach ($components as $type => $val) { ?>
                                        <td><input type="number" name="marks[<?php echo $marks[$type]['id'] ?? ''; ?>]" value="<?php echo $marks[$type]['marks'] ?? 0; ?>" min="0"></td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        </table>
                        <button type="submit" name="update_marks">Update Marks</button>
                    </form>
                <?php } ?>

                <?php if ($current_week > 5 && $mid1_completed) { ?>
                    <!-- Mid2 Table -->
                    <h3>Mid2 Marks</h3>
                    <form method="POST">
                        <input type="hidden" name="timeline" value="mid2">
                        <label>Select Subject</label>
                        <select name="subject" required>
                            <option value="">Select a Subject</option>
                            <?php 
                            mysqli_data_seek($subjects_result, 0);
                            while ($subject = mysqli_fetch_assoc($subjects_result)) { ?>
                                <option value="<?php echo htmlspecialchars($subject['subject_name']); ?>">
                                    <?php echo htmlspecialchars($subject['subject_name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                        <label>Add ICA Component</label>
                        <select name="component_type">
                            <option value="experiment">Experiment</option>
                            <option value="assignment">Assignment</option>
                            <option value="group_assignment">Group Assignment</option>
                        </select>
                        <button type="submit" name="add_column">Add Column</button>
                    </form>
                    <form method="POST">
                        <input type="hidden" name="timeline" value="mid2">
                        <table>
                            <tr>
                                <th>Student</th>
                                <th>Mid2 (Compulsory)</th>
                                <?php 
                                $components = [];
                                while ($row = mysqli_fetch_assoc($mid2_data)) {
                                    if ($row['component_type'] != 'mid2') {
                                        $components[$row['component_type']] = true;
                                    }
                                }
                                mysqli_data_seek($mid2_data, 0);
                                foreach ($components as $type => $val) {
                                    echo "<th>" . ucfirst(str_replace('_', ' ', $type)) . "</th>";
                                }
                                ?>
                            </tr>
                            <?php 
                            $students = [];
                            while ($row = mysqli_fetch_assoc($mid2_data)) {
                                $students[$row['student_name']][$row['component_type']] = ['id' => $row['id'], 'marks' => $row['marks']];
                            }
                            foreach ($students as $student => $marks) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student); ?></td>
                                    <td><input type="number" name="marks[<?php echo $marks['mid2']['id']; ?>]" value="<?php echo $marks['mid2']['marks']; ?>" min="0" required></td>
                                    <?php foreach ($components as $type => $val) { ?>
                                        <td><input type="number" name="marks[<?php echo $marks[$type]['id'] ?? ''; ?>]" value="<?php echo $marks[$type]['marks'] ?? 0; ?>" min="0"></td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        </table>
                        <button type="submit" name="update_marks">Update Marks</button>
                    </form>
                <?php } ?>

                <?php if ($current_week > 10 && $mid2_completed) { ?>
                    <!-- Final Table -->
                    <h3>Final Marks</h3>
                    <form method="POST">
                        <input type="hidden" name="timeline" value="final">
                        <label>Select Subject</label>
                        <select name="subject" required>
                            <option value="">Select a Subject</option>
                            <?php 
                            mysqli_data_seek($subjects_result, 0);
                            while ($subject = mysqli_fetch_assoc($subjects_result)) { ?>
                                <option value="<?php echo htmlspecialchars($subject['subject_name']); ?>">
                                    <?php echo htmlspecialchars($subject['subject_name']); ?>
                                </option>
                            <?php } ?>
                        </select>
                        <label>Final Submission Type</label>
                        <select name="component_type">
                            <option value="presentation">Presentation</option>
                            <option value="project">Project</option>
                            <option value="group_project">Group Project</option>
                        </select>
                        <button type="submit" name="add_column">Add Column</button>
                    </form>
                    <form method="POST">
                        <input type="hidden" name="timeline" value="final">
                        <table>
                            <tr>
                                <th>Student</th>
                                <th>Final Submission (Compulsory)</th>
                                <th>Avg Experiments</th>
                                <th>Avg Assignments</th>
                            </tr>
                            <?php 
                            $students = [];
                            while ($row = mysqli_fetch_assoc($final_data)) {
                                $students[$row['student_name']][$row['component_type']] = ['id' => $row['id'], 'marks' => $row['marks']];
                            }
                            foreach ($students as $student => $marks) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($student); ?></td>
                                    <td><input type="number" name="marks[<?php echo $marks['final_submission']['id']; ?>]" value="<?php echo $marks['final_submission']['marks']; ?>" min="0" required></td>
                                    <td><?php echo round($experiment_avg[$student], 2); ?></td>
                                    <td><?php echo round($assignment_avg[$student], 2); ?></td>
                                </tr>
                            <?php } ?>
                        </table>
                        <button type="submit" name="update_marks">Update Marks</button>
                    </form>
                <?php } ?>

                <p><a href="teacher_dashboard.php">Back to Dashboard</a></p>
            </div>
        </div>
    </div>

    <script>
        function toggleTheme() {
            document.body.classList.toggle('dark-mode');
            localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
        }

        if (localStorage.getItem('theme') === 'dark') {
            document.body.classList.add('dark-mode');
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</body>
</html>